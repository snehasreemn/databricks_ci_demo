# Databricks notebook source
# MAGIC %md
# MAGIC #Create silver_clickstream delta table

# COMMAND ----------

# MAGIC %sql
# MAGIC use catalog shopshere;
# MAGIC use schema medallion_architecture;

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE TABLE IF NOT EXISTS silver_clickstream (
# MAGIC     event_id BIGINT,
# MAGIC     customer_id INT,
# MAGIC     session_id STRING,
# MAGIC     event_time TIMESTAMP,
# MAGIC     event_type STRING,
# MAGIC     product_id INT,
# MAGIC     page STRING,
# MAGIC     device_type STRING,
# MAGIC     event_date DATE,
# MAGIC     event_hour INT,
# MAGIC     is_anonymous BOOLEAN
# MAGIC )
# MAGIC USING DELTA;

# COMMAND ----------

# MAGIC %md
# MAGIC #Read sources

# COMMAND ----------

from pyspark.sql.functions import *
from pyspark.sql.window import Window

bronze_clickstream = spark.table("bronze_clickstream")

valid_customers = (
    spark.table("silver_customers")
    .filter("is_current = true")
    .select(col("customer_id").cast("int"))
)

valid_products = (
    spark.table("silver_products")
    .select("product_id")
)


# COMMAND ----------

# MAGIC %md
# MAGIC #Remove duplicate events - keep latest version of the event

# COMMAND ----------

window_spec = (
    Window
    .partitionBy("event_id")
    .orderBy(col("event_time").desc())
)

clickstream_dedup = (
    bronze_clickstream
    .withColumn(
        "rn",
        row_number().over(window_spec)
    )
    .filter("rn = 1")
    .drop("rn")
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Validate Event Timestamp

# COMMAND ----------

# MAGIC %md
# MAGIC Rules:
# MAGIC - Event time cannot be null
# MAGIC - Event time cannot be in the future

# COMMAND ----------

valid_events = (
    clickstream_dedup
    .filter(
        col("event_time").isNotNull()
    )
    .filter(
        col("event_time") <= current_timestamp()
    )
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Quarantine invalid events

# COMMAND ----------

invalid_events = (
    clickstream_dedup
    .filter(
        col("event_time").isNull()
    )
    .filter(
        col("event_time") > current_timestamp()
    )
)

invalid_events.write \
    .format("delta") \
    .mode("append") \
    .saveAsTable("quarantine_clickstream")

# COMMAND ----------

# MAGIC %md
# MAGIC #Standardize Event Types

# COMMAND ----------

# MAGIC %md
# MAGIC VALID_EVENTS 
# MAGIC -     "SEARCH",
# MAGIC -     "PRODUCT_VIEW",
# MAGIC -     "ADD_TO_CART",
# MAGIC -     "REMOVE_FROM_CART",
# MAGIC -     "CHECKOUT",
# MAGIC -     "PURCHASE"
# MAGIC

# COMMAND ----------

VALID_EVENTS = [
    "SEARCH",
    "PRODUCT_VIEW",
    "ADD_TO_CART",
    "REMOVE_FROM_CART",
    "CHECKOUT",
    "PURCHASE"
]

clickstream_cleaned = (
    valid_events
    .withColumn(
        "event_type",
        upper(trim(col("event_type")))
    )
    .withColumn(
        "event_type",
        when(
            col("event_type").isin("PRODUCT VIEW", "PRODUCTVIEW", "VIEW_PRODUCT"),
            "PRODUCT_VIEW"
        )
        .when(
            col("event_type").isin("ADD TO CART", "ADDTOCART"),
            "ADD_TO_CART"
        )
        .when(
            col("event_type").isin("REMOVE FROM CART", "REMOVEFROMCART"),
            "REMOVE_FROM_CART"
        )
        .when(
            col("event_type").isin("BUY", "ORDER", "PURCHASED"),
            "PURCHASE"
        )
        .otherwise(col("event_type"))
    )
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Validate Customer IDs - Customer is nullable - only validate if value exists

# COMMAND ----------

valid_customer_events = (

    clickstream_cleaned.alias("c")

    .join(
        valid_customers.alias("cust"),
        clickstream_cleaned.customer_id ==
        valid_customers.customer_id,
        "left"
    )

    .filter(
        col("c.customer_id").isNull()
        |
        col("cust.customer_id").isNotNull()
    )

    .select("c.*")
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Validate Product Ids when present - product is nullable

# COMMAND ----------

valid_product_events = (

    valid_customer_events.alias("c")

    .join(
        valid_products.alias("p"),
        valid_customer_events.product_id ==
        valid_products.product_id,
        "left"
    )

    .filter(
        col("c.product_id").isNull()
        |
        col("p.product_id").isNotNull()
    )

    .select("c.*")
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Derive Event date

# COMMAND ----------

clickstream_enriched = (
    valid_product_events
    .withColumn(
        "event_date",
        to_date(col("event_time"))
    )
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Derive Event Hour

# COMMAND ----------

clickstream_enriched = (
    clickstream_enriched
    .withColumn(
        "event_hour",
        hour(col("event_time"))
    )
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Identify Anonymous sessions

# COMMAND ----------

# MAGIC %md
# MAGIC customer_id IS NULL
# MAGIC → Anonymous Visitor

# COMMAND ----------

silver_clickstream_df = (
    clickstream_enriched
    .withColumn(
        "is_anonymous",
        when(
            col("customer_id").isNull(),
            True
        )
        .otherwise(False)
    )
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Merge into silver_clickstream

# COMMAND ----------

from delta.tables import DeltaTable

target = DeltaTable.forName(
    spark,
    "silver_clickstream"
)

# Deduplicate by event_id to prevent multiple source rows matching the same target
silver_clickstream_df = silver_clickstream_df.dropDuplicates(["event_id"])

(target.alias("t").merge(
    silver_clickstream_df.alias("s"),
    "t.event_id = s.event_id"
)

.whenMatchedUpdate(
    set={
        "customer_id": "s.customer_id",
        "session_id": "s.session_id",
        "event_time": "s.event_time",
        "event_type": "s.event_type",
        "product_id": "s.product_id",
        "page": "s.page",
        "device_type": "s.device_type",
        "event_date": "s.event_date",
        "event_hour": "s.event_hour",
        "is_anonymous": "s.is_anonymous"
    }
)

.whenNotMatchedInsert(
    values={
        "event_id": "s.event_id",
        "customer_id": "s.customer_id",
        "session_id": "s.session_id",
        "event_time": "s.event_time",
        "event_type": "s.event_type",
        "product_id": "s.product_id",
        "page": "s.page",
        "device_type": "s.device_type",
        "event_date": "s.event_date",
        "event_hour": "s.event_hour",
        "is_anonymous": "s.is_anonymous"
    }
)

.execute())

# COMMAND ----------

# MAGIC %md
# MAGIC #Validate silver_clickstream data load

# COMMAND ----------

spark.table("medallion_architecture.silver_clickstream").limit(4).display()