# Databricks notebook source
# MAGIC %md
# MAGIC #Create silver_orders delta table

# COMMAND ----------

# MAGIC %sql
# MAGIC use catalog shopshere;
# MAGIC use schema medallion_architecture;

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE TABLE IF NOT EXISTS silver_orders (
# MAGIC     order_id BIGINT,
# MAGIC     customer_id INT,
# MAGIC     order_date TIMESTAMP,
# MAGIC     order_status STRING,
# MAGIC     shipping_address STRING,
# MAGIC     total_amount DECIMAL(18,2),
# MAGIC     created_at TIMESTAMP,
# MAGIC     updated_at TIMESTAMP,
# MAGIC     is_cancelled BOOLEAN,
# MAGIC     is_returned BOOLEAN,
# MAGIC     is_completed BOOLEAN
# MAGIC )
# MAGIC USING DELTA;

# COMMAND ----------

# MAGIC %md
# MAGIC #Read source tables

# COMMAND ----------

from pyspark.sql.functions import *
from pyspark.sql.window import Window

bronze_orders = spark.table("bronze_orders")

customers = (
    spark.table("silver_customers")
    .filter("is_current = true")
    .select("customer_id")
    .distinct()
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Remove duplicates - keep latest version of each order

# COMMAND ----------

window_spec = (
    Window
    .partitionBy("order_id")
    .orderBy(col("updated_at").desc())
)

orders_dedup = (
    bronze_orders
    .withColumn(
        "rn",
        row_number().over(window_spec)
    )
    .filter("rn = 1")
    .drop("rn")
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Standardize order_status

# COMMAND ----------

orders_cleaned = (
    orders_dedup

    .withColumn(
        "order_status",
        upper(trim(col("order_status")))
    )
)

# COMMAND ----------

# MAGIC %md
# MAGIC #set default status to PLACED if not in VALID status

# COMMAND ----------

valid_statuses = [
    "PLACED",
    "CONFIRMED",
    "SHIPPED",
    "DELIVERED",
    "CANCELLED",
    "RETURNED"
]

orders_cleaned = (
    orders_cleaned
    .withColumn(
        "order_status",
        when(
            col("order_status").isin(valid_statuses),
            col("order_status")
        )
        .otherwise("PLACED")
    )
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Validate Customers

# COMMAND ----------

orders_valid_customers = (
    orders_cleaned.alias("o")
    .join(
        customers.alias("c"),
        "customer_id",
        "inner"
    )
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Validate Dates

# COMMAND ----------

orders_valid_dates = (
    orders_valid_customers
    .filter(
        col("order_date") <= current_timestamp()
    )
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Handle Negative amounts

# COMMAND ----------

# MAGIC %md
# MAGIC ##Create a quarantine table for bad records having negative amounts

# COMMAND ----------

bad_orders = (
    orders_valid_dates
    .filter(col("total_amount") < 0)
)

bad_orders.write \
    .format("delta") \
    .mode("append") \
    .saveAsTable("quarantine_orders")

# COMMAND ----------

# MAGIC %md
# MAGIC ##Load good records with amount>0 into silver table

# COMMAND ----------

good_orders = (
    orders_valid_dates
    .filter(col("total_amount") >= 0)
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Create Business flags

# COMMAND ----------

silver_orders_df = (
    good_orders
    .withColumn(
        "is_cancelled",
        when(
            col("order_status") == "CANCELLED",
            lit(True)
        ).otherwise(lit(False))
    )
    .withColumn(
        "is_returned",
        when(
            col("order_status") == "RETURNED",
            lit(True)
        ).otherwise(lit(False))
    )
    .withColumn(
        "is_completed",
        when(
            col("order_status") == "DELIVERED",
            lit(True)
        ).otherwise(lit(False))
    )
)

# COMMAND ----------

from delta.tables import DeltaTable

target = DeltaTable.forName(
    spark,
    "silver_orders"
)

(target.alias("t").merge(
    silver_orders_df.alias("s"),
    "t.order_id = s.order_id"
)

.whenMatchedUpdate(
    set={
        "customer_id": "s.customer_id",
        "order_date": "s.order_date",
        "order_status": "s.order_status",
        "shipping_address": "s.shipping_address",
        "total_amount": "s.total_amount",
        "updated_at": "s.updated_at",
        "is_cancelled": "s.is_cancelled",
        "is_returned": "s.is_returned",
        "is_completed": "s.is_completed"
    }
)

.whenNotMatchedInsert(
    values={
        "order_id": "s.order_id",
        "customer_id": "s.customer_id",
        "order_date": "s.order_date",
        "order_status": "s.order_status",
        "shipping_address": "s.shipping_address",
        "total_amount": "s.total_amount",
        "created_at": "s.created_at",
        "updated_at": "s.updated_at",
        "is_cancelled": "s.is_cancelled",
        "is_returned": "s.is_returned",
        "is_completed": "s.is_completed"
    }
)

.execute())

# COMMAND ----------

# MAGIC %md
# MAGIC #Validate silver_orders table load

# COMMAND ----------

spark.table("medallion_architecture.silver_orders").limit(3).display()

# COMMAND ----------

