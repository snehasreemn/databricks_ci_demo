# Databricks notebook source
# MAGIC %md
# MAGIC #Create silver_customers delta table if not exists

# COMMAND ----------

# MAGIC %sql
# MAGIC use catalog shopshere;
# MAGIC use schema medallion_architecture;

# COMMAND ----------

# MAGIC %sql
# MAGIC use catalog workspace;
# MAGIC use schema medallion_architecture;
# MAGIC drop table medallion_architecture.silver_customers;

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE TABLE IF NOT EXISTS silver_customers (
# MAGIC     customer_id INT,
# MAGIC     first_name STRING,
# MAGIC     last_name STRING,
# MAGIC     email STRING,
# MAGIC     phone STRING,
# MAGIC     city STRING,
# MAGIC     state STRING,
# MAGIC     country STRING,
# MAGIC     customer_status STRING,
# MAGIC     created_at TIMESTAMP,
# MAGIC     updated_at TIMESTAMP,
# MAGIC     hash_value STRING,
# MAGIC     effective_start_date TIMESTAMP,
# MAGIC     effective_end_date TIMESTAMP,
# MAGIC     is_current BOOLEAN
# MAGIC )
# MAGIC USING DELTA;
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC #Load bronze_customers data into dataframe

# COMMAND ----------

from pyspark.sql.functions import *
from pyspark.sql.window import Window

bronze_df = spark.table("bronze_customers")

# COMMAND ----------

# MAGIC %md
# MAGIC #Standardize and Validate data in bronze_customers

# COMMAND ----------

cleaned_df = (
    bronze_df

    # trim whitespace
    .withColumn("first_name", trim(col("first_name")))
    .withColumn("last_name", trim(col("last_name")))
    .withColumn("email", lower(trim(col("email"))))
    .withColumn("phone", trim(col("phone")))
    .withColumn("city", initcap(trim(col("city"))))
    .withColumn("state", upper(trim(col("state"))))
    .withColumn("country", upper(trim(col("country"))))
    .withColumn("customer_status", upper(trim(col("customer_status"))))

    # email validation
    .withColumn(
        "email",
        when(
            col("email").rlike(
                r'^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$'
            ),
            col("email")
        )
    )

    # missing phone
    .withColumn(
        "phone",
        when(length(trim(col("phone"))) == 0, None)
        .otherwise(col("phone"))
    )

    # missing email
    .withColumn(
        "email",
        when(length(trim(col("email"))) == 0, None)
        .otherwise(col("email"))
    )

    # customer status validation
    .withColumn(
        "customer_status",
        when(
            col("customer_status").isin("ACTIVE", "INACTIVE"),
            col("customer_status")
        )
        .otherwise("INACTIVE")
    )
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Remove duplicate records from bronze_customers

# COMMAND ----------

window_spec = (
    Window
    .partitionBy("customer_id")
    .orderBy(
        col("updated_at").desc(),
        col("created_at").desc()
    )
)

dedup_df = (
    cleaned_df
    .withColumn(
        "rn",
        row_number().over(window_spec)
    )
    .filter("rn = 1")
    .drop("rn")
)

#dedup_df=cleaned_df.dropDuplicates()

# COMMAND ----------

# MAGIC %md
# MAGIC #Generate Hash value

# COMMAND ----------

scd_source = (
    dedup_df
    .withColumn(
        "hash_value",
        sha2(
            concat_ws(
                "|",
                coalesce(col("first_name"), lit("")),
                coalesce(col("last_name"), lit("")),
                coalesce(col("email"), lit("")),
                coalesce(col("phone"), lit("")),
                coalesce(col("city"), lit("")),
                coalesce(col("state"), lit("")),
                coalesce(col("country"), lit("")),
                coalesce(col("customer_status"), lit(""))
            ),
            256
        )
    )
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Create SCD2 staging dataset

# COMMAND ----------

# MAGIC %md
# MAGIC ##Fetch the current records from silver_customers into dataFrame

# COMMAND ----------

current_silver = (
    spark.table("silver_customers")
    .filter("is_current = true")
)

# COMMAND ----------

# MAGIC %md
# MAGIC ##Identify Changed records

# COMMAND ----------

changes_df = (
    scd_source.alias("s")
    .join(
        current_silver.alias("t"),
        "customer_id",
        "left"
    )
    .filter(
        col("t.customer_id").isNull()
        |
        (col("s.hash_value") != col("t.hash_value"))
    )
)


# COMMAND ----------

# MAGIC %md
# MAGIC ##Create Staged updates

# COMMAND ----------

staged_updates = (

    # updates
    changes_df.selectExpr(
        "customer_id as merge_key",
        "*"
    )

    .unionByName(

        # inserts
        changes_df.selectExpr(
            "NULL as merge_key",
            "*"
        ),
        allowMissingColumns=True
    )
)

# COMMAND ----------

from delta.tables import DeltaTable

target = DeltaTable.forName(
    spark,
    "silver_customers"
)

# Select only source-side columns to avoid duplicate column names from the join
src_cols = [
    "customer_id",
    col("s.first_name"), col("s.last_name"), col("s.email"),
    col("s.phone"), col("s.city"), col("s.state"), col("s.country"),
    col("s.customer_status"), col("s.created_at"), col("s.updated_at"),
    col("s.hash_value")
]

staged_updates = (
    changes_df.select(col("customer_id").alias("merge_key"), *src_cols)
    .unionByName(
        changes_df.select(lit(None).cast("int").alias("merge_key"), *src_cols),
        allowMissingColumns=True
    )
)

(target.alias("t").merge(
    staged_updates.alias("s"),
    """
    t.customer_id = s.merge_key
    AND t.is_current = true
    """
)

.whenMatchedUpdate(
    condition="""
        t.hash_value <> s.hash_value
    """,
    set={
        "is_current": "false",
        "effective_end_date": "current_timestamp()"
    }
)

.whenNotMatchedInsert(
    values={
        "customer_id": "s.customer_id",
        "first_name": "s.first_name",
        "last_name": "s.last_name",
        "email": "s.email",
        "phone": "s.phone",
        "city": "s.city",
        "state": "s.state",
        "country": "s.country",
        "customer_status": "s.customer_status",
        "created_at": "s.created_at",
        "updated_at": "s.updated_at",
        "hash_value": "s.hash_value",
        "effective_start_date": "current_timestamp()",
        "effective_end_date": "CAST('9999-12-31 23:59:59' AS TIMESTAMP)",
        "is_current": "true"
    }
)

.execute())

# COMMAND ----------

# MAGIC %md
# MAGIC #Validate data in silver_customers table

# COMMAND ----------

#spark.table("medallion_architecture.silver_customers").limit(4).display()

spark.sql("select count(*) from silver_customers where is_current=False").display()

# COMMAND ----------

