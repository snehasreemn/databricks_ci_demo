# Databricks notebook source
# MAGIC %md
# MAGIC #Create silver_order_items Delta table

# COMMAND ----------

# MAGIC %sql
# MAGIC use catalog shopshere;
# MAGIC use schema medallion_architecture;

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE TABLE IF NOT EXISTS silver_order_items (
# MAGIC     order_item_id BIGINT,
# MAGIC     order_id BIGINT,
# MAGIC     product_id INT,
# MAGIC     quantity INT,
# MAGIC     unit_price DECIMAL(18,2),
# MAGIC     discount DECIMAL(10,4),
# MAGIC
# MAGIC     gross_amount DECIMAL(18,2),
# MAGIC     discount_amount DECIMAL(18,2),
# MAGIC     net_amount DECIMAL(18,2),
# MAGIC
# MAGIC     created_at TIMESTAMP,
# MAGIC     updated_at TIMESTAMP
# MAGIC )
# MAGIC USING DELTA;

# COMMAND ----------

# MAGIC %md
# MAGIC #Read from source tables

# COMMAND ----------

from pyspark.sql.functions import *

bronze_order_items = spark.table("bronze_order_items")

valid_orders = (
    spark.table("silver_orders")
    .select("order_id")
    .distinct()
)

valid_products = (
    spark.table("silver_products")
    .select("product_id")
    .distinct()
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Remove duplicates

# COMMAND ----------

from pyspark.sql.window import Window

window_spec = (
    Window
    .partitionBy("order_item_id")
    .orderBy(col("updated_at").desc())
)

dedup_df = (
    bronze_order_items
    .withColumn(
        "rn",
        row_number().over(window_spec)
    )
    .filter("rn = 1")
    .drop("rn")
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Validate Foreign keys

# COMMAND ----------

# MAGIC %md
# MAGIC ##Validate Orders

# COMMAND ----------

order_valid_df = (
    dedup_df.alias("oi")
    .join(
        valid_orders.alias("o"),
        "order_id",
        "inner"
    )
)

# COMMAND ----------

# MAGIC %md
# MAGIC ##Validate Products

# COMMAND ----------

validated_df = (
    order_valid_df.alias("oi")
    .join(
        valid_products.alias("p"),
        "product_id",
        "inner"
    )
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Quarantine Invalid Records

# COMMAND ----------

# MAGIC %md
# MAGIC ##Create a quarantine table for invalid records

# COMMAND ----------

invalid_records = (
    validated_df
    .filter(
        (col("quantity") <= 0) |
        (col("unit_price") < 0) |
        (col("discount") < 0) |
        (col("discount") > 1)
    )
)

invalid_records.write \
    .format("delta") \
    .mode("append") \
    .saveAsTable("quarantine_order_items")

# COMMAND ----------

# MAGIC %md
# MAGIC ##Keep only valid records

# COMMAND ----------

valid_records = (
    validated_df
    .filter(
        (col("quantity") > 0) &
        (col("unit_price") >= 0) &
        (col("discount") >= 0) &
        (col("discount") <= 1)
    )
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Apply Business calculations

# COMMAND ----------

silver_order_items_df = (
    valid_records

    .withColumn(
        "gross_amount",
        round(
            col("quantity") * col("unit_price"),
            2
        )
    )

    .withColumn(
        "discount_amount",
        round(
            col("gross_amount") * col("discount"),
            2
        )
    )

    .withColumn(
        "net_amount",
        round(
            col("gross_amount") - col("discount_amount"),
            2
        )
    )
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Merge into silver_orders table

# COMMAND ----------

from delta.tables import DeltaTable

target = DeltaTable.forName(
    spark,
    "silver_order_items"
)

(target.alias("t").merge(
    silver_order_items_df.alias("s"),
    "t.order_item_id = s.order_item_id"
)

.whenMatchedUpdate(
    set={
        "order_id": "s.order_id",
        "product_id": "s.product_id",
        "quantity": "s.quantity",
        "unit_price": "s.unit_price",
        "discount": "s.discount",
        "gross_amount": "s.gross_amount",
        "discount_amount": "s.discount_amount",
        "net_amount": "s.net_amount",
        "updated_at": "s.updated_at"
    }
)

.whenNotMatchedInsert(
    values={
        "order_item_id": "s.order_item_id",
        "order_id": "s.order_id",
        "product_id": "s.product_id",
        "quantity": "s.quantity",
        "unit_price": "s.unit_price",
        "discount": "s.discount",
        "gross_amount": "s.gross_amount",
        "discount_amount": "s.discount_amount",
        "net_amount": "s.net_amount",
        "created_at": "s.created_at",
        "updated_at": "s.updated_at"
    }
)

.execute())

# COMMAND ----------

# MAGIC %md
# MAGIC #Validate silver_order_items data load

# COMMAND ----------

spark.table("medallion_architecture.silver_order_items").limit(4).display()