# Databricks notebook source
# MAGIC %md
# MAGIC #Create silver_inventory delta table

# COMMAND ----------

# MAGIC %sql
# MAGIC use catalog shopshere;
# MAGIC use schema medallion_architecture;

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE TABLE IF NOT EXISTS silver_inventory (
# MAGIC     inventory_date DATE,
# MAGIC     product_id INT,
# MAGIC     warehouse_id STRING,
# MAGIC     available_quantity INT,
# MAGIC     reserved_quantity INT,
# MAGIC     reorder_level INT,
# MAGIC     available_to_sell INT,
# MAGIC     inventory_status STRING
# MAGIC )
# MAGIC USING DELTA;

# COMMAND ----------

# MAGIC %md
# MAGIC #Read source tables

# COMMAND ----------

from pyspark.sql.functions import *
from pyspark.sql.window import Window

bronze_inventory = spark.table("bronze_inventory")

valid_products = (
    spark.table("silver_products")
    .select("product_id")
    .distinct()
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Remove Duplicates - Assume the latest snapshot should be retained for a product, warehouse, and date.

# COMMAND ----------

window_spec = (
    Window
    .partitionBy(
        "inventory_date",
        "product_id",
        "warehouse_id"
    )
    .orderBy(col("inventory_date").desc())
)

inventory_dedup = (
    bronze_inventory
    .withColumn(
        "rn",
        row_number().over(window_spec)
    )
    .filter("rn = 1")
    .drop("rn")
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Validate Product IDs

# COMMAND ----------

inventory_valid = (
    inventory_dedup.alias("i")
    .join(
        valid_products.alias("p"),
        "product_id",
        "inner"
    )
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Validate Inventory values

# COMMAND ----------

# MAGIC %md
# MAGIC - available_quantity >= 0
# MAGIC - reserved_quantity >= 0
# MAGIC - reorder_level >= 0
# MAGIC - reserved_quantity <= available_quantity

# COMMAND ----------

# MAGIC %md
# MAGIC ##Quarantine invalid records

# COMMAND ----------

invalid_inventory = (
    inventory_valid
    .filter(
        (col("available_quantity") < 0)
        |
        (col("reserved_quantity") < 0)
        |
        (col("reorder_level") < 0)
        |
        (col("reserved_quantity") > col("available_quantity"))
    )
)

invalid_inventory.write \
    .format("delta") \
    .mode("append") \
    .saveAsTable("quarantine_inventory")

# COMMAND ----------

# MAGIC %md
# MAGIC ##Keep valid records

# COMMAND ----------

valid_inventory = (
    inventory_valid
    .filter(
        (col("available_quantity") >= 0)
        &
        (col("reserved_quantity") >= 0)
        &
        (col("reorder_level") >= 0)
        &
        (col("reserved_quantity") <= col("available_quantity"))
    )
)


# COMMAND ----------

# MAGIC %md
# MAGIC #Calculate Available to sell

# COMMAND ----------

inventory_calc = (
    valid_inventory
    .withColumn(
        "available_to_sell",
        col("available_quantity")
        - col("reserved_quantity")
    )
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Classify Inventory status

# COMMAND ----------

# MAGIC %md
# MAGIC ##Business Rules

# COMMAND ----------

# MAGIC %md
# MAGIC available_to_sell <= 0
# MAGIC        ↓
# MAGIC OUT_OF_STOCK
# MAGIC
# MAGIC available_to_sell <= reorder_level
# MAGIC        ↓
# MAGIC LOW_STOCK
# MAGIC
# MAGIC otherwise
# MAGIC        ↓
# MAGIC IN_STOCK

# COMMAND ----------

silver_inventory_df = (
    inventory_calc
    .withColumn(
        "inventory_status",
        when(
            col("available_to_sell") <= 0,
            "OUT_OF_STOCK"
        )
        .when(
            col("available_to_sell")
            <= col("reorder_level"),
            "LOW_STOCK"
        )
        .otherwise("IN_STOCK")
    )
)


# COMMAND ----------

# MAGIC %md
# MAGIC #Merge into Silver Inventory

# COMMAND ----------

# MAGIC %md
# MAGIC KeyColumns
# MAGIC + inventory_date
# MAGIC + product_id
# MAGIC + warehouse_id

# COMMAND ----------

from delta.tables import DeltaTable

target = DeltaTable.forName(
    spark,
    "silver_inventory"
)

(target.alias("t").merge(
    silver_inventory_df.alias("s"),
    """
    t.inventory_date = s.inventory_date
    AND t.product_id = s.product_id
    AND t.warehouse_id = s.warehouse_id
    """
)

.whenMatchedUpdate(
    set={
        "available_quantity": "s.available_quantity",
        "reserved_quantity": "s.reserved_quantity",
        "reorder_level": "s.reorder_level",
        "available_to_sell": "s.available_to_sell",
        "inventory_status": "s.inventory_status"
    }
)

.whenNotMatchedInsert(
    values={
        "inventory_date": "s.inventory_date",
        "product_id": "s.product_id",
        "warehouse_id": "s.warehouse_id",
        "available_quantity": "s.available_quantity",
        "reserved_quantity": "s.reserved_quantity",
        "reorder_level": "s.reorder_level",
        "available_to_sell": "s.available_to_sell",
        "inventory_status": "s.inventory_status"
    }
)

.execute())

# COMMAND ----------

# MAGIC %md
# MAGIC #Validate silver_inventory data load

# COMMAND ----------

spark.table("medallion_architecture.silver_inventory").limit(4).display()

# COMMAND ----------

