# Databricks notebook source
# MAGIC %md
# MAGIC #Create silver_payments delta table

# COMMAND ----------

# MAGIC %sql
# MAGIC use catalog shopshere;
# MAGIC use schema medallion_architecture;

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE TABLE IF NOT EXISTS silver_payments (
# MAGIC     payment_id BIGINT,
# MAGIC     order_id BIGINT,
# MAGIC     payment_method STRING,
# MAGIC     payment_amount DECIMAL(18,2),
# MAGIC     payment_status STRING,
# MAGIC     payment_date TIMESTAMP,
# MAGIC     updated_at TIMESTAMP,
# MAGIC     is_successful BOOLEAN,
# MAGIC     is_failed BOOLEAN,
# MAGIC     is_refunded BOOLEAN
# MAGIC )
# MAGIC USING DELTA;

# COMMAND ----------

# MAGIC %md
# MAGIC #Read source tables

# COMMAND ----------

from pyspark.sql.functions import *
from pyspark.sql.window import Window

bronze_payments = spark.table("bronze_payments")

valid_orders = (
    spark.table("silver_orders")
    .select("order_id")
    .distinct()
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Remove Duplicates - keep only the latest payment version

# COMMAND ----------

window_spec = (
    Window
    .partitionBy("payment_id")
    .orderBy(col("updated_at").desc())
)

payments_dedup = (
    bronze_payments
    .withColumn(
        "rn",
        row_number().over(window_spec)
    )
    .filter("rn = 1")
    .drop("rn")
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Validate Orders

# COMMAND ----------

# MAGIC %md
# MAGIC ##Ensure the payment belongs to a valid order

# COMMAND ----------

payments_valid = (
    payments_dedup.alias("p")
    .join(
        valid_orders.alias("o"),
        "order_id",
        "inner"
    )
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Standardize payment method

# COMMAND ----------

payments_cleaned = (
    payments_valid
    .withColumn(
        "payment_method",
        upper(trim(col("payment_method")))
    )
)

# COMMAND ----------

# MAGIC %md
# MAGIC ##Normalize common values

# COMMAND ----------

payments_cleaned = (
    payments_cleaned
    .withColumn(
        "payment_method",
        when(
            col("payment_method").isin("UPI", "GOOGLEPAY", "PHONEPE", "GPAY"),
            "UPI"
        )
        .when(
            col("payment_method").isin("CREDIT CARD", "DEBIT CARD", "CARD"),
            "CARD"
        )
        .when(
            col("payment_method").isin("CASH ON DELIVERY", "COD"),
            "COD"
        )
        .otherwise(col("payment_method"))
    )
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Standardize payment status

# COMMAND ----------

valid_statuses = [
    "SUCCESS",
    "FAILED",
    "PENDING",
    "REFUNDED"
]

payments_cleaned = (
    payments_cleaned
    .withColumn(
        "payment_status",
        upper(trim(col("payment_status")))
    )
    .withColumn(
        "payment_status",
        when(
            col("payment_status").isin(valid_statuses),
            col("payment_status")
        )
        .otherwise("PENDING")
    )
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Validate Payment amount

# COMMAND ----------

# MAGIC %md
# MAGIC - payment_amount>0
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ##Invalid payments go to the quarantine table

# COMMAND ----------

invalid_payments = (
    payments_cleaned
    .filter(
        col("payment_amount") < 0
    )
)

invalid_payments.write \
    .format("delta") \
    .mode("append") \
    .saveAsTable("quarantine_payments")

# COMMAND ----------

# MAGIC %md
# MAGIC ##Keep records with only valid payments

# COMMAND ----------

valid_payments = (
    payments_cleaned
    .filter(
        col("payment_amount") >= 0
    )
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Create Business flags

# COMMAND ----------

silver_payments_df = (
    valid_payments

    .withColumn(
        "is_successful",
        when(
            col("payment_status") == "SUCCESS",
            True
        ).otherwise(False)
    )

    .withColumn(
        "is_failed",
        when(
            col("payment_status") == "FAILED",
            True
        ).otherwise(False)
    )

    .withColumn(
        "is_refunded",
        when(
            col("payment_status") == "REFUNDED",
            True
        ).otherwise(False)
    )
)


# COMMAND ----------

# MAGIC %md
# MAGIC #Merge into Silver Payments

# COMMAND ----------

from delta.tables import DeltaTable

target = DeltaTable.forName(
    spark,
    "silver_payments"
)

(target.alias("t").merge(
    silver_payments_df.alias("s"),
    "t.payment_id = s.payment_id"
)

.whenMatchedUpdate(
    set={
        "order_id": "s.order_id",
        "payment_method": "s.payment_method",
        "payment_amount": "s.payment_amount",
        "payment_status": "s.payment_status",
        "payment_date": "s.payment_date",
        "updated_at": "s.updated_at",
        "is_successful": "s.is_successful",
        "is_failed": "s.is_failed",
        "is_refunded": "s.is_refunded"
    }
)

.whenNotMatchedInsert(
    values={
        "payment_id": "s.payment_id",
        "order_id": "s.order_id",
        "payment_method": "s.payment_method",
        "payment_amount": "s.payment_amount",
        "payment_status": "s.payment_status",
        "payment_date": "s.payment_date",
        "updated_at": "s.updated_at",
        "is_successful": "s.is_successful",
        "is_failed": "s.is_failed",
        "is_refunded": "s.is_refunded"
    }
)

.execute())

# COMMAND ----------

# MAGIC %md
# MAGIC #Validate silver_payments data load

# COMMAND ----------

spark.table("medallion_architecture.silver_payments").limit(4).display()

# COMMAND ----------

