# Databricks notebook source
# MAGIC %md
# MAGIC #Create silver_products Delta Table

# COMMAND ----------

# MAGIC %sql
# MAGIC use catalog shopshere;
# MAGIC use schema medallion_architecture;

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE TABLE IF NOT EXISTS silver_products (
# MAGIC     product_id INT,
# MAGIC     product_name STRING,
# MAGIC     category STRING,
# MAGIC     subcategory STRING,
# MAGIC     brand STRING,
# MAGIC     price DECIMAL(18,2),
# MAGIC     cost DECIMAL(18,2),
# MAGIC     supplier_id STRING,
# MAGIC     product_status STRING,
# MAGIC     updated_at TIMESTAMP
# MAGIC )
# MAGIC USING DELTA;

# COMMAND ----------

# MAGIC %md
# MAGIC #Read Bronze Products

# COMMAND ----------

from pyspark.sql.functions import *
from pyspark.sql.window import Window

bronze_products = spark.table("bronze_products")

# COMMAND ----------

# MAGIC %md
# MAGIC #Remove Duplicates

# COMMAND ----------

window_spec = (
    Window
    .partitionBy("product_id")
    .orderBy(col("updated_at").desc())
)

products_dedup = (
    bronze_products
    .withColumn(
        "rn",
        row_number().over(window_spec)
    )
    .filter("rn = 1")
    .drop("rn")
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Standardize Text fields

# COMMAND ----------

products_cleaned = (
    products_dedup

    .withColumn(
        "product_name",
        initcap(trim(col("product_name")))
    )

    .withColumn(
        "category",
        initcap(trim(col("category")))
    )

    .withColumn(
        "subcategory",
        initcap(trim(col("subcategory")))
    )

    .withColumn(
        "brand",
        initcap(trim(col("brand")))
    )

    .withColumn(
        "supplier_id",
        upper(trim(col("supplier_id")))
    )

    .withColumn(
        "product_status",
        upper(trim(col("product_status")))
    )
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Validate Product Status

# COMMAND ----------

spark.sql("select distinct product_status from bronze_products").display()

# COMMAND ----------

products_cleaned = (
    products_cleaned
    .withColumn(
        "product_status",
        when(
            col("product_status").isin(
                "ACTIVE",
                "DISCONTINUED"
            ),
            col("product_status")
        )
        .otherwise("ACTIVE")
    )
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Identify Invalid Records

# COMMAND ----------

# MAGIC %md
# MAGIC - price >= 0
# MAGIC - cost >= 0
# MAGIC - category IS NOT NULL
# MAGIC - product_name IS NOT NULL
# MAGIC

# COMMAND ----------

invalid_products = (
    products_cleaned
    .filter(
        (col("price") < 0)
        |
        (col("cost") < 0)
        |
        col("category").isNull()
        |
        (trim(col("category")) == "")
        |
        col("product_name").isNull()
    )
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Quarantine Bad Records

# COMMAND ----------

invalid_products.write \
    .format("delta") \
    .mode("append") \
    .saveAsTable("quarantine_products")

# COMMAND ----------

# MAGIC %md
# MAGIC #Keep Valid Products

# COMMAND ----------

valid_products = (
    products_cleaned
    .filter(
        (col("price") >= 0)
        &
        (col("cost") >= 0)
        &
        col("category").isNotNull()
        &
        (trim(col("category")) != "")
        &
        col("product_name").isNotNull()
    )
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Merge into silver_products

# COMMAND ----------

from delta.tables import DeltaTable

target = DeltaTable.forName(
    spark,
    "silver_products"
)

(target.alias("t").merge(
    valid_products.alias("s"),
    """
    t.product_id = s.product_id
    """
)

.whenMatchedUpdate(
    set={
        "product_name": "s.product_name",
        "category": "s.category",
        "subcategory": "s.subcategory",
        "brand": "s.brand",
        "price": "s.price",
        "cost": "s.cost",
        "supplier_id": "s.supplier_id",
        "product_status": "s.product_status",
        "updated_at": "s.updated_at"
    }
)

.whenNotMatchedInsert(
    values={
        "product_id": "s.product_id",
        "product_name": "s.product_name",
        "category": "s.category",
        "subcategory": "s.subcategory",
        "brand": "s.brand",
        "price": "s.price",
        "cost": "s.cost",
        "supplier_id": "s.supplier_id",
        "product_status": "s.product_status",
        "updated_at": "s.updated_at"
    }
)

.execute())

# COMMAND ----------

# MAGIC %md
# MAGIC #Validate silver_products data load

# COMMAND ----------

spark.table("medallion_architecture.silver_products").limit(4).display()

# COMMAND ----------

