# Databricks notebook source
# MAGIC %md
# MAGIC #Define Clickstream Source and Checkpoint paths

# COMMAND ----------

# MAGIC %sql
# MAGIC use catalog shopshere;
# MAGIC use schema medallion_architecture;

# COMMAND ----------

# Source location
source_path = "/Volumes/shopshere/quickstart_schema/sandbox/clickstream/"

# Streaming checkpoint
checkpoint_location = "/Volumes/shopshere/quickstart_schema/sandbox/clickstream_checkpoint/"

# COMMAND ----------

# MAGIC %md
# MAGIC #Read the Incremental Stream data for Clickstream

# COMMAND ----------

from pyspark.sql.types import *

clickstream_schema = StructType([
    StructField("event_id", LongType(), False),      # Primary Key
    StructField("customer_id", FloatType(), True), # Nullable
    StructField("session_id", StringType(), True),
    StructField("event_time", TimestampType(), True),
    StructField("event_type", StringType(), True),
    StructField("product_id", IntegerType(), True),  # Nullable
    StructField("page", StringType(), True),
    StructField("device_type", StringType(), True)
])

clickstream_df = (
    spark.readStream
         .format("cloudFiles")
         .schema(clickstream_schema)
         .option("cloudFiles.format", "json")
         .option("header", "true")
         .load(source_path)
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Write the incremental stream of data into bronze_customers table

# COMMAND ----------

clickstream_df.writeStream.option("checkpointLocation", checkpoint_location).trigger(
    availableNow=True
).toTable("medallion_architecture.bronze_clickstream")

# COMMAND ----------

spark.table("medallion_architecture.bronze_clickstream").count()