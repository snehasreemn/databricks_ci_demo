# Databricks notebook source
# MAGIC %md
# MAGIC #Create gold_inventory_sales delta table

# COMMAND ----------

# MAGIC %sql
# MAGIC use catalog shopshere;
# MAGIC use schema medallion_architecture;

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE TABLE IF NOT EXISTS gold_inventory_sales (
# MAGIC     product_id INT,
# MAGIC     product_name STRING,
# MAGIC     category STRING,
# MAGIC     sales_quantity BIGINT,
# MAGIC     available_inventory INT,
# MAGIC     reserved_inventory INT,
# MAGIC     available_to_sell INT,
# MAGIC     inventory_status STRING
# MAGIC )
# MAGIC USING DELTA;

# COMMAND ----------

# MAGIC %md
# MAGIC #For gold_inventory_sales, combine:
# MAGIC
# MAGIC - silver_order_items (sales quantity)
# MAGIC - silver_inventory (inventory snapshot)
# MAGIC - silver_products (product details)

# COMMAND ----------

# MAGIC %md
# MAGIC ##Business Logic
# MAGIC
# MAGIC sales_quantity =
# MAGIC SUM(quantity)
# MAGIC Available Inventory
# MAGIC
# MAGIC available_inventory =
# MAGIC available_quantity
# MAGIC Reserved Inventory
# MAGIC
# MAGIC reserved_inventory =
# MAGIC reserved_quantity
# MAGIC Available To Sell
# MAGIC
# MAGIC available_to_sell =
# MAGIC available_quantity - reserved_quantity
# MAGIC Inventory Status
# MAGIC
# MAGIC available_to_sell <= 0
# MAGIC → OUT_OF_STOCK
# MAGIC  
# MAGIC available_to_sell <= reorder_level
# MAGIC → LOW_STOCK
# MAGIC  
# MAGIC otherwise
# MAGIC → HEALTHY_STOCK
# MAGIC
# MAGIC Note: Silver used IN_STOCK. For Gold reporting, map IN_STOCK → HEALTHY_STOCK.

# COMMAND ----------

# MAGIC %md
# MAGIC #Aggregate Product sales - use delivered orders only

# COMMAND ----------

from pyspark.sql.functions import *

orders_df = (
    spark.table("silver_orders")
    .filter(col("order_status") == "DELIVERED")
)

order_items_df = spark.table("silver_order_items")

# COMMAND ----------

sales_df = (
    orders_df.alias("o")
    .join(
        order_items_df.alias("oi"),
        "order_id"
    )
    .groupBy("product_id")
    .agg(
        sum("quantity").alias("sales_quantity")
    )
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Latest Inventory Snapshot - If inventory is daily, use latest snapshot.

# COMMAND ----------

from pyspark.sql.window import Window

inventory_df = spark.table("silver_inventory")

w = Window.partitionBy(
    "product_id"
).orderBy(
    col("inventory_date").desc()
)

latest_inventory = (
    inventory_df
    .withColumn(
        "rn",
        row_number().over(w)
    )
    .filter("rn = 1")
    .drop("rn")
)


# COMMAND ----------

# MAGIC %md
# MAGIC #Standardize Gold Inventory Status

# COMMAND ----------

inventory_gold = (
    latest_inventory
    .withColumn(
        "inventory_status",
        when(
            col("available_to_sell") <= 0,
            "OUT_OF_STOCK"
        )
        .when(
            col("available_to_sell")
            <= col("reorder_level"),
            "LOW_STOCK"
        )
        .otherwise("HEALTHY_STOCK")
    )
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Join Products

# COMMAND ----------

products_df = spark.table("silver_products")

# COMMAND ----------

gold_inventory_sales = (
    sales_df.alias("s")
    .join(
        inventory_gold.alias("i"),
        "product_id",
        "inner"
    )
    .join(
        products_df.alias("p"),
        "product_id",
        "left"
    )
    .select(
        "product_id",
        "product_name",
        "category",
        "sales_quantity",
        col("available_quantity")
            .alias("available_inventory"),
        col("reserved_quantity")
            .alias("reserved_inventory"),
        "available_to_sell",
        "inventory_status"
    )
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Write to gold_inventory_sales

# COMMAND ----------

(
    gold_inventory_sales
    .write
    .format("delta")
    .mode("overwrite")
    .saveAsTable("gold_inventory_sales")
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Business Question

# COMMAND ----------

# MAGIC %md
# MAGIC ##1.Which High-Selling Products Are Out of Stock?

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT *
# MAGIC FROM gold_inventory_sales
# MAGIC WHERE inventory_status = 'OUT_OF_STOCK'
# MAGIC ORDER BY sales_quantity DESC;

# COMMAND ----------

# MAGIC %md
# MAGIC ##2.Which Products Need Replenishment?

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT *
# MAGIC FROM gold_inventory_sales
# MAGIC WHERE inventory_status IN (
# MAGIC     'OUT_OF_STOCK',
# MAGIC     'LOW_STOCK'
# MAGIC )
# MAGIC ORDER BY sales_quantity DESC;

# COMMAND ----------

# MAGIC %md
# MAGIC ##3.Which Products Have Excess Inventory?
# MAGIC Sales Quantity < 100
# MAGIC AND
# MAGIC Available Inventory > 500

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT *
# MAGIC FROM gold_inventory_sales
# MAGIC WHERE sales_quantity < 100
# MAGIC AND available_inventory > 500
# MAGIC ORDER BY available_inventory DESC;