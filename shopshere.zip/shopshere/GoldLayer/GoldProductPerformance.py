# Databricks notebook source
# MAGIC %md
# MAGIC #Create gold_product_performance table

# COMMAND ----------

# MAGIC %sql
# MAGIC use catalog shopshere;
# MAGIC use schema medallion_architecture;

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE TABLE IF NOT EXISTS gold_product_performance (
# MAGIC     product_id INT,
# MAGIC     product_name STRING,
# MAGIC     category STRING,
# MAGIC     units_sold BIGINT,
# MAGIC     total_orders BIGINT,
# MAGIC     gross_revenue DECIMAL(18,2),
# MAGIC     discount_amount DECIMAL(18,2),
# MAGIC     net_revenue DECIMAL(18,2),
# MAGIC     average_selling_price DECIMAL(18,2),
# MAGIC     unique_customers BIGINT,
# MAGIC     revenue_rank INT,
# MAGIC     category_rank INT
# MAGIC )
# MAGIC USING DELTA;

# COMMAND ----------

# MAGIC %md
# MAGIC #For gold_product_performance, need to combine:
# MAGIC - silver_order_items
# MAGIC - silver_orders
# MAGIC - silver_products

# COMMAND ----------

# MAGIC %md
# MAGIC #Business Metrics
# MAGIC | Metric                  | Calculation                  |
# MAGIC | ----------------------- | ---------------------------- |
# MAGIC | units\_sold             | SUM(quantity)                |
# MAGIC | total\_orders           | COUNT(DISTINCT order\_id)    |
# MAGIC | gross\_revenue          | SUM(gross\_amount)           |
# MAGIC | discount\_amount        | SUM(discount\_amount)        |
# MAGIC | net\_revenue            | SUM(net\_amount)             |
# MAGIC | average\_selling\_price | net\_revenue / units\_sold   |
# MAGIC | unique\_customers       | COUNT(DISTINCT customer\_id) |
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC #Build Product Metrics

# COMMAND ----------

# MAGIC %md
# MAGIC ##Read source tables

# COMMAND ----------

from pyspark.sql.functions import *
from pyspark.sql.window import Window

orders_df = (
    spark.table("silver_orders")
    .filter(
        col("order_status") == "DELIVERED"
    )
)

order_items_df = spark.table("silver_order_items")

products_df = spark.table("silver_products")

# COMMAND ----------

# MAGIC %md
# MAGIC ##Join source tables

# COMMAND ----------

product_sales = (
    orders_df.alias("o")
    .join(
        order_items_df.alias("oi"),
        "order_id"
    )
    .join(
        products_df.alias("p"),
        "product_id"
    )
)

# COMMAND ----------

# MAGIC %md
# MAGIC ##Aggregate Product metrics

# COMMAND ----------

product_metrics = (
    product_sales
    .groupBy(
        "product_id",
        "product_name",
        "category"
    )
    .agg(

        sum("quantity")
            .alias("units_sold"),

        countDistinct("order_id")
            .alias("total_orders"),

        round(
            sum("gross_amount"),
            2
        ).alias("gross_revenue"),

        round(
            sum("discount_amount"),
            2
        ).alias("discount_amount"),

        round(
            sum("net_amount"),
            2
        ).alias("net_revenue"),

        countDistinct("customer_id")
            .alias("unique_customers")
    )
)

# COMMAND ----------

# MAGIC %md
# MAGIC ##Calculate average selling price

# COMMAND ----------

product_metrics = (
    product_metrics
    .withColumn(
        "average_selling_price",
        round(
            col("net_revenue")
            / col("units_sold"),
            2
        )
    )
)

# COMMAND ----------

# MAGIC %md
# MAGIC ##Revenue rank - across all products

# COMMAND ----------

revenue_window = Window.orderBy(
    col("net_revenue").desc()
)

product_metrics = (
    product_metrics
    .withColumn(
        "revenue_rank",
        dense_rank().over(
            revenue_window
        )
    )
)


# COMMAND ----------

# MAGIC %md
# MAGIC ##Category Rank - rank within each categories

# COMMAND ----------

category_window = (
    Window
    .partitionBy("category")
    .orderBy(
        col("net_revenue").desc()
    )
)

gold_product_performance = (
    product_metrics
    .withColumn(
        "category_rank",
        dense_rank().over(
            category_window
        )
    )
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Save to gold_product_performance table

# COMMAND ----------

(
    gold_product_performance
    .select(
        "product_id",
        "product_name",
        "category",
        "units_sold",
        "total_orders",
        col("gross_revenue").cast("decimal(18,2)"),
        col("discount_amount").cast("decimal(18,2)"),
        col("net_revenue").cast("decimal(18,2)"),
        col("average_selling_price").cast("decimal(18,2)"),
        "unique_customers",
        "revenue_rank",
        "category_rank"
    )
    .write
    .format("delta")
    .mode("overwrite")
    .saveAsTable(
        "gold_product_performance"
    )
)


# COMMAND ----------

# MAGIC %md
# MAGIC #Validate data load into gold_product_performance

# COMMAND ----------

spark.table("medallion_architecture.gold_product_performance").limit(4).display()

# COMMAND ----------

# MAGIC %md
# MAGIC #Business Questions

# COMMAND ----------

# MAGIC %md
# MAGIC ##1.What are the Top 3 Products by Revenue Within Every Category?

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT
# MAGIC     product_id,
# MAGIC     product_name,
# MAGIC     category,
# MAGIC     net_revenue,
# MAGIC     category_rank
# MAGIC FROM gold_product_performance
# MAGIC WHERE category_rank <= 3
# MAGIC ORDER BY
# MAGIC     category,
# MAGIC     category_rank;