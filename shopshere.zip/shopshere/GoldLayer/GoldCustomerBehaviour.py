# Databricks notebook source
# MAGIC %md
# MAGIC #Create gold_customer_behaviour delta table

# COMMAND ----------

# MAGIC %sql
# MAGIC use catalog shopshere;
# MAGIC use schema medallion_architecture;

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE TABLE IF NOT EXISTS gold_customer_behavior (
# MAGIC     customer_id INT,
# MAGIC     customer_name STRING,
# MAGIC     sessions BIGINT,
# MAGIC     product_views BIGINT,
# MAGIC     add_to_cart_events BIGINT,
# MAGIC     checkout_events BIGINT,
# MAGIC     purchases BIGINT,
# MAGIC     view_to_cart_rate DECIMAL(10,2),
# MAGIC     cart_to_checkout_rate DECIMAL(10,2),
# MAGIC     checkout_to_purchase_rate DECIMAL(10,2),
# MAGIC     overall_conversion_rate DECIMAL(10,2)
# MAGIC )
# MAGIC USING DELTA;
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC #Business metrics definition
# MAGIC | Metric                       | Calculation                                    |
# MAGIC | ---------------------------- | ---------------------------------------------- |
# MAGIC | sessions                     | COUNT(DISTINCT session\_id)                    |
# MAGIC | product\_views               | COUNT(PRODUCT\_VIEW)                           |
# MAGIC | add\_to\_cart\_events        | COUNT(ADD\_TO\_CART)                           |
# MAGIC | checkout\_events             | COUNT(CHECKOUT)                                |
# MAGIC | purchases                    | COUNT(PURCHASE)                                |
# MAGIC | view\_to\_cart\_rate         | add\_to\_cart\_events / product\_views × 100   |
# MAGIC | cart\_to\_checkout\_rate     | checkout\_events / add\_to\_cart\_events × 100 |
# MAGIC | checkout\_to\_purchase\_rate | purchases / checkout\_events × 100             |
# MAGIC | overall\_conversion\_rate    | purchases / sessions × 100                     |
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC #Customer Base

# COMMAND ----------

from pyspark.sql.functions import *

customers_df = (
    spark.table("silver_customers")
    .filter("is_current = true")
    .select(
        "customer_id",
        concat_ws(
            " ",
            col("first_name"),
            col("last_name")
        ).alias("customer_name")
    )
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Aggregate Clickstream events - using valid events

# COMMAND ----------

# MAGIC %md
# MAGIC - SEARCH
# MAGIC - PRODUCT_VIEW
# MAGIC - ADD_TO_CART
# MAGIC - REMOVE_FROM_CART
# MAGIC - CHECKOUT
# MAGIC - PURCHASE

# COMMAND ----------

clickstream_df = (
    spark.table("silver_clickstream")
    .filter(col("customer_id").isNotNull())
)

# COMMAND ----------

# MAGIC %md
# MAGIC ##Aggregation metrics

# COMMAND ----------

behavior_metrics = (
    clickstream_df
    .groupBy("customer_id")
    .agg(

        countDistinct("session_id")
            .alias("sessions"),

        sum(
            when(
                col("event_type") == "PRODUCT_VIEW",
                1
            ).otherwise(0)
        ).alias("product_views"),

        sum(
            when(
                col("event_type") == "ADD_TO_CART",
                1
            ).otherwise(0)
        ).alias("add_to_cart_events"),

        sum(
            when(
                col("event_type") == "CHECKOUT",
                1
            ).otherwise(0)
        ).alias("checkout_events"),

        sum(
            when(
                col("event_type") == "PURCHASE",
                1
            ).otherwise(0)
        ).alias("purchases")
    )
)

# COMMAND ----------

# MAGIC %md
# MAGIC ##Calculate Funnel Conversion Rates

# COMMAND ----------

behavior_metrics = (
    behavior_metrics

    .withColumn(
        "view_to_cart_rate",
        round(
            when(
                col("product_views") > 0,
                col("add_to_cart_events")
                * 100.0
                / col("product_views")
            ).otherwise(0),
            2
        )
    )

    .withColumn(
        "cart_to_checkout_rate",
        round(
            when(
                col("add_to_cart_events") > 0,
                col("checkout_events")
                * 100.0
                / col("add_to_cart_events")
            ).otherwise(0),
            2
        )
    )

    .withColumn(
        "checkout_to_purchase_rate",
        round(
            when(
                col("checkout_events") > 0,
                col("purchases")
                * 100.0
                / col("checkout_events")
            ).otherwise(0),
            2
        )
    )

    .withColumn(
        "overall_conversion_rate",
        round(
            when(
                col("sessions") > 0,
                col("purchases")
                * 100.0
                / col("sessions")
            ).otherwise(0),
            2
        )
    )
)

# COMMAND ----------

# MAGIC %md
# MAGIC ##Alternative Purchase Metric from Orders

# COMMAND ----------

purchase_orders = (
    spark.table("silver_orders")
    .filter(col("order_status") == "DELIVERED")
    .groupBy("customer_id")
    .agg(
        countDistinct("order_id")
        .alias("purchases")
    )
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Build Customer Behaviour table

# COMMAND ----------

gold_customer_behavior = (
    customers_df
    .join(
        behavior_metrics,
        "customer_id",
        "left"
    )
    .fillna(0)
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Write to gold_customer_behaviour table

# COMMAND ----------

(
    gold_customer_behavior
    .select(
        "customer_id",
        "customer_name",
        "sessions",
        "product_views",
        "add_to_cart_events",
        "checkout_events",
        "purchases",
        col("view_to_cart_rate").cast("decimal(10,2)"),
        col("cart_to_checkout_rate").cast("decimal(10,2)"),
        col("checkout_to_purchase_rate").cast("decimal(10,2)"),
        col("overall_conversion_rate").cast("decimal(10,2)")
    )
    .write
    .format("delta")
    .mode("overwrite")
    .saveAsTable("gold_customer_behavior")
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Business Questions Answered

# COMMAND ----------

# MAGIC %md
# MAGIC ##1.Which customers have the best conversion rate?

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT *
# MAGIC FROM gold_customer_behavior
# MAGIC ORDER BY overall_conversion_rate DESC limit 100;

# COMMAND ----------

# MAGIC %md
# MAGIC ##2.Which customers abandon carts most often?

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT
# MAGIC     customer_id,
# MAGIC     add_to_cart_events,
# MAGIC     checkout_events
# MAGIC FROM gold_customer_behavior
# MAGIC WHERE add_to_cart_events > checkout_events;

# COMMAND ----------

# MAGIC %md
# MAGIC ##3.What is the overall funnel conversion?

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT
# MAGIC     ROUND(
# MAGIC         SUM(purchases) * 100.0 /
# MAGIC         SUM(sessions),
# MAGIC         2
# MAGIC     ) AS overall_conversion_rate
# MAGIC FROM gold_customer_behavior;

# COMMAND ----------

# MAGIC %md
# MAGIC ##4. Where are customers dropping off?

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT
# MAGIC     AVG(view_to_cart_rate),
# MAGIC     AVG(cart_to_checkout_rate),
# MAGIC     AVG(checkout_to_purchase_rate)
# MAGIC FROM gold_customer_behavior;