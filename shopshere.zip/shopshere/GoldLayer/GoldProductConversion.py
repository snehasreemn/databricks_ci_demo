# Databricks notebook source
# MAGIC %md
# MAGIC #Create gold_product_conversion delta table

# COMMAND ----------

# MAGIC %sql
# MAGIC use catalog shopshere;
# MAGIC use schema medallion_architecture;

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE TABLE IF NOT EXISTS gold_product_conversion (
# MAGIC     product_id INT,
# MAGIC     product_name STRING,
# MAGIC     category STRING,
# MAGIC     product_views BIGINT,
# MAGIC     add_to_cart_count BIGINT,
# MAGIC     checkout_count BIGINT,
# MAGIC     purchase_count BIGINT,
# MAGIC     view_to_cart_rate DECIMAL(10,2),
# MAGIC     cart_to_purchase_rate DECIMAL(10,2),
# MAGIC     overall_conversion_rate DECIMAL(10,2)
# MAGIC )
# MAGIC USING DELTA;
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC #Funnel definition
# MAGIC PRODUCT_VIEW
# MAGIC         ↓
# MAGIC ADD_TO_CART
# MAGIC         ↓
# MAGIC CHECKOUT
# MAGIC         ↓
# MAGIC PURCHASE

# COMMAND ----------

# MAGIC %md
# MAGIC ### For gold_product_conversion, we primarily use silver_clickstream and optionally silver_products for product details.

# COMMAND ----------

# MAGIC %md
# MAGIC #Read source data

# COMMAND ----------

from pyspark.sql.functions import *

clickstream_df = spark.table("silver_clickstream")

products_df = spark.table("silver_products")

# COMMAND ----------

# MAGIC %md
# MAGIC #Aggregate Product Events

# COMMAND ----------

product_events = (
    clickstream_df
    .filter(col("product_id").isNotNull())
    .groupBy("product_id")
    .agg(

        sum(
            when(
                col("event_type") == "PRODUCT_VIEW",
                1
            ).otherwise(0)
        ).alias("product_views"),

        sum(
            when(
                col("event_type") == "ADD_TO_CART",
                1
            ).otherwise(0)
        ).alias("add_to_cart_count"),

        sum(
            when(
                col("event_type") == "CHECKOUT",
                1
            ).otherwise(0)
        ).alias("checkout_count"),

        sum(
            when(
                col("event_type") == "PURCHASE",
                1
            ).otherwise(0)
        ).alias("purchase_count")
    )
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Calculate conversion rates

# COMMAND ----------

# MAGIC %md
# MAGIC - View-->Cart rate: 
# MAGIC add_to_cart_count / product_views * 100
# MAGIC - Cart --> Purchase Rate: 
# MAGIC purchase_count / add_to_cart_count * 100
# MAGIC - Overall Conversion Rate: 
# MAGIC purchase_count / product_views * 100

# COMMAND ----------

product_conversion = (
    product_events

    .withColumn(
        "view_to_cart_rate",
        round(
            when(
                col("product_views") > 0,
                col("add_to_cart_count")
                * 100.0
                / col("product_views")
            ).otherwise(0),
            2
        )
    )

    .withColumn(
        "cart_to_purchase_rate",
        round(
            when(
                col("add_to_cart_count") > 0,
                col("purchase_count")
                * 100.0
                / col("add_to_cart_count")
            ).otherwise(0),
            2
        )
    )

    .withColumn(
        "overall_conversion_rate",
        round(
            when(
                col("product_views") > 0,
                col("purchase_count")
                * 100.0
                / col("product_views")
            ).otherwise(0),
            2
        )
    )
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Add product details

# COMMAND ----------

gold_product_conversion = (
    product_conversion
    .join(
        products_df.select(
            "product_id",
            "product_name",
            "category"
        ),
        "product_id",
        "left"
    )
)

# COMMAND ----------

# MAGIC %md
# MAGIC #write to gold_product_conversion table

# COMMAND ----------

(
    gold_product_conversion
    .select(
        "product_id",
        "product_name",
        "category",
        "product_views",
        "add_to_cart_count",
        "checkout_count",
        "purchase_count",
        col("view_to_cart_rate").cast("decimal(10,2)"),
        col("cart_to_purchase_rate").cast("decimal(10,2)"),
        col("overall_conversion_rate").cast("decimal(10,2)")
    )
    .write
    .format("delta")
    .mode("overwrite")
    .saveAsTable("gold_product_conversion")
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Business Question

# COMMAND ----------

# MAGIC %md
# MAGIC ##1.Which Products Have High Interest But Low Conversion?

# COMMAND ----------

# MAGIC %md
# MAGIC ###Business definition
# MAGIC High Interest:
# MAGIC product_views > average(product_views)
# MAGIC
# MAGIC Low Conversion:
# MAGIC overall_conversion_rate < 5%

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT
# MAGIC     product_id,
# MAGIC     product_name,
# MAGIC     category,
# MAGIC     product_views,
# MAGIC     purchase_count,
# MAGIC     overall_conversion_rate
# MAGIC FROM gold_product_conversion
# MAGIC WHERE product_views >
# MAGIC (
# MAGIC     SELECT AVG(product_views)
# MAGIC     FROM gold_product_conversion
# MAGIC )
# MAGIC AND overall_conversion_rate < 5
# MAGIC ORDER BY product_views DESC;

# COMMAND ----------

# MAGIC %md
# MAGIC #Useful Business Insights

# COMMAND ----------

# MAGIC %md
# MAGIC ##Products Viewed Frequently But Rarely Purchased

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT *
# MAGIC FROM gold_product_conversion
# MAGIC WHERE overall_conversion_rate < 3
# MAGIC ORDER BY product_views DESC;
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ##Best Converting Products

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT *
# MAGIC FROM gold_product_conversion
# MAGIC ORDER BY overall_conversion_rate DESC limit 10;

# COMMAND ----------

# MAGIC %md
# MAGIC ##Products With Cart Abandonment Issues

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT *,
# MAGIC (100 - cart_to_purchase_rate) AS abandonment_rate
# MAGIC FROM gold_product_conversion
# MAGIC ORDER BY abandonment_rate DESC limit 10;