# Databricks notebook source
# MAGIC %md
# MAGIC #Create gold_customer_360 table

# COMMAND ----------

# MAGIC %sql
# MAGIC use catalog shopshere;
# MAGIC use schema medallion_architecture;

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE TABLE IF NOT EXISTS gold_customer_360 (
# MAGIC     customer_id INT,
# MAGIC     customer_name STRING,
# MAGIC     first_order_date DATE,
# MAGIC     last_order_date DATE,
# MAGIC     total_orders BIGINT,
# MAGIC     total_quantity BIGINT,
# MAGIC     total_spend DECIMAL(18,2),
# MAGIC     average_order_value DECIMAL(18,2),
# MAGIC     days_since_last_order INT,
# MAGIC     preferred_category STRING,
# MAGIC     preferred_device STRING,
# MAGIC     customer_segment STRING
# MAGIC )
# MAGIC USING DELTA;

# COMMAND ----------

# MAGIC %md
# MAGIC #Segmentation rules: Documented business rules:
# MAGIC
# MAGIC - VIP	total_spend >= 50000
# MAGIC - HIGH_VALUE	total_spend >= 20000
# MAGIC - LOYAL	total_orders >= 10
# MAGIC - ACTIVE	last order within 90 days
# MAGIC - INACTIVE	no order in 90+ days

# COMMAND ----------

# MAGIC %md
# MAGIC #Priority
# MAGIC VIP
# MAGIC ↓
# MAGIC HIGH_VALUE
# MAGIC ↓
# MAGIC LOYAL
# MAGIC ↓
# MAGIC ACTIVE
# MAGIC ↓
# MAGIC INACTIVE

# COMMAND ----------

# MAGIC %md
# MAGIC #For gold_customer_360, need to combine data from:
# MAGIC - silver_customers
# MAGIC - silver_orders
# MAGIC - silver_order_items
# MAGIC - silver_products
# MAGIC - silver_clickstream

# COMMAND ----------

# MAGIC %md
# MAGIC #Customer Master

# COMMAND ----------

from pyspark.sql.functions import *

customers = (
    spark.table("silver_customers")
    .filter("is_current = true")
    .select(
        "customer_id",
        concat_ws(
            " ",
            col("first_name"),
            col("last_name")
        ).alias("customer_name")
    )
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Order Metrics - Use only completed/delivered orders

# COMMAND ----------

orders = (
    spark.table("silver_orders")
    .filter(
        col("order_status") == "DELIVERED"
    )
)

order_items = spark.table("silver_order_items")

# COMMAND ----------

# MAGIC %md
# MAGIC #Join Customer master and orders

# COMMAND ----------

customer_orders = (
    orders.alias("o")
    .join(
        order_items.alias("oi"),
        "order_id"
    )
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Customer Sales Metrics

# COMMAND ----------

customer_metrics = (
    customer_orders
    .groupBy("customer_id")
    .agg(
        min(to_date("order_date"))
            .alias("first_order_date"),

        max(to_date("order_date"))
            .alias("last_order_date"),

        countDistinct("order_id")
            .alias("total_orders"),

        sum("quantity")
            .alias("total_quantity"),

        round(
            sum("net_amount"),
            2
        ).alias("total_spend")
    )
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Average order value

# COMMAND ----------

customer_metrics = (
    customer_metrics
    .withColumn(
        "average_order_value",
        round(
            col("total_spend")
            / col("total_orders"),
            2
        )
    )
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Days since last order

# COMMAND ----------

customer_metrics = (
    customer_metrics
    .withColumn(
        "days_since_last_order",
        datediff(
            current_date(),
            col("last_order_date")
        )
    )
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Preferred categories
# MAGIC Join with Products

# COMMAND ----------

products = spark.table("silver_products")

# COMMAND ----------

# MAGIC %md
# MAGIC ##Customer-category purchases

# COMMAND ----------

category_counts = (
    orders.alias("o")
    .join(order_items.alias("oi"), "order_id")
    .join(products.alias("p"), "product_id")
    .groupBy(
        "customer_id",
        "p.category"
    )
    .agg(
        sum("quantity").alias("qty")
    )
)

# COMMAND ----------

# MAGIC %md
# MAGIC ##Find top category

# COMMAND ----------

from pyspark.sql.window import Window

w = Window.partitionBy(
    "customer_id"
).orderBy(
    col("qty").desc()
)

preferred_category = (
    category_counts
    .withColumn(
        "rn",
        row_number().over(w)
    )
    .filter("rn = 1")
    .select(
        "customer_id",
        col("category")
        .alias("preferred_category")
    )
)

# COMMAND ----------

#preferred_category.display()

# COMMAND ----------

# MAGIC %md
# MAGIC #Preferred Device

# COMMAND ----------

# MAGIC %md
# MAGIC ##From clickstream

# COMMAND ----------

events = spark.table("silver_clickstream")

# COMMAND ----------

# MAGIC %md
# MAGIC ##Count device usage

# COMMAND ----------

device_counts = (
    events
    .filter(
        col("customer_id").isNotNull()
    )
    .groupBy(
        "customer_id",
        "device_type"
    )
    .count()
)

# COMMAND ----------

# MAGIC %md
# MAGIC ##Find Top Device

# COMMAND ----------

w = Window.partitionBy(
    "customer_id"
).orderBy(
    col("count").desc()
)

preferred_device = (
    device_counts
    .withColumn(
        "rn",
        row_number().over(w)
    )
    .filter("rn = 1")
    .select(
        "customer_id",
        col("device_type")
        .alias("preferred_device")
    )
)

# COMMAND ----------

#category_counts.display()
#spark.sql("select distinct customer_id from silver_clickstream").display()

# COMMAND ----------

# MAGIC %md
# MAGIC #Customer Segmentation

# COMMAND ----------

customer_metrics = (
    customer_metrics
    .withColumn(
        "customer_segment",

        when(
            col("total_spend") >= 50000,
            "VIP"
        )

        .when(
            col("total_spend") >= 20000,
            "HIGH_VALUE"
        )

        .when(
            col("total_orders") >= 10,
            "LOYAL"
        )

        .when(
            col("days_since_last_order") <= 90,
            "ACTIVE"
        )

        .otherwise("INACTIVE")
    )
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Build customer360

# COMMAND ----------

gold_customer_360 = (
    customers
    .join(
        customer_metrics,
        "customer_id",
        "left"
    )
    .join(
        preferred_category,
        "customer_id",
        "left"
    )
    .join(
        preferred_device,
        "customer_id",
        "left"
    )
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Write to Gold table gold_customer_360

# COMMAND ----------

(
    gold_customer_360
    .select(
        "customer_id",
        "customer_name",
        "first_order_date",
        "last_order_date",
        "total_orders",
        "total_quantity",
        col("total_spend").cast("decimal(18,2)"),
        col("average_order_value").cast("decimal(18,2)"),
        "days_since_last_order",
        "preferred_category",
        "preferred_device",
        "customer_segment"
    )
    .write
    .format("delta")
    .mode("overwrite")
    .saveAsTable("gold_customer_360")
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Business Questions Answered
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ##1.Who are our VIP customers?

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT *
# MAGIC FROM gold_customer_360
# MAGIC WHERE customer_segment = 'VIP';

# COMMAND ----------

# MAGIC %md
# MAGIC ##2. Which customers are inactive?

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT *
# MAGIC FROM gold_customer_360
# MAGIC WHERE customer_segment = 'INACTIVE';

# COMMAND ----------

# MAGIC %md
# MAGIC ##3.What is each customer's lifetime value?

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT
# MAGIC     customer_id,
# MAGIC     customer_name,
# MAGIC     total_spend
# MAGIC FROM gold_customer_360;

# COMMAND ----------

# MAGIC %md
# MAGIC ##4. Which Category does a customer prefer?

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT
# MAGIC     customer_id,
# MAGIC     preferred_category
# MAGIC FROM gold_customer_360;

# COMMAND ----------

# MAGIC %md
# MAGIC ##5. Which device is most used by customer?

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT
# MAGIC     preferred_device,
# MAGIC     COUNT(*)
# MAGIC FROM gold_customer_360
# MAGIC --where preferred_device is not null
# MAGIC GROUP BY preferred_device;