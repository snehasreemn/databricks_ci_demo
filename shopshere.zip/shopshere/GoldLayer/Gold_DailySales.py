# Databricks notebook source
# MAGIC %md
# MAGIC #Create Gold Daily Sales table

# COMMAND ----------

# MAGIC %sql
# MAGIC use catalog shopshere;
# MAGIC use schema medallion_architecture;

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE TABLE IF NOT EXISTS gold_daily_sales (
# MAGIC     sales_date DATE,
# MAGIC     total_orders BIGINT,
# MAGIC     completed_orders BIGINT,
# MAGIC     cancelled_orders BIGINT,
# MAGIC     returned_orders BIGINT,
# MAGIC     gross_sales DECIMAL(18,2),
# MAGIC     discount_amount DECIMAL(18,2),
# MAGIC     net_sales DECIMAL(18,2),
# MAGIC     average_order_value DECIMAL(18,2)
# MAGIC )
# MAGIC USING DELTA;

# COMMAND ----------

# MAGIC %md
# MAGIC #silver_orders
# MAGIC - order_id
# MAGIC - order_date
# MAGIC - order_status
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC #silver_order_items
# MAGIC - order_id
# MAGIC - gross_amount
# MAGIC - discount_amount
# MAGIC - net_amount

# COMMAND ----------

# MAGIC %md
# MAGIC #Business Daily Sales Dataset

# COMMAND ----------

# MAGIC %md
# MAGIC ##Join silver_orders and silver_order_items

# COMMAND ----------

from pyspark.sql.functions import *

orders_df = spark.table("silver_orders")

order_items_df = spark.table("silver_order_items")

sales_df = (
    orders_df.alias("o")
    .join(
        order_items_df.alias("oi"),
        "order_id",
        "inner"
    )
    .withColumn(
        "sales_date",
        to_date("order_date")
    )
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Aggregate metrics

# COMMAND ----------

daily_sales_df = (
    sales_df
    .groupBy("sales_date")
    .agg(

        countDistinct("order_id")
            .alias("total_orders"),

        countDistinct(
            when(
                col("order_status") == "DELIVERED",
                col("order_id")
            )
        ).alias("completed_orders"),

        countDistinct(
            when(
                col("order_status") == "CANCELLED",
                col("order_id")
            )
        ).alias("cancelled_orders"),

        countDistinct(
            when(
                col("order_status") == "RETURNED",
                col("order_id")
            )
        ).alias("returned_orders"),

        round(
            sum("gross_amount"),
            2
        ).alias("gross_sales"),

        round(
            sum("discount_amount"),
            2
        ).alias("discount_amount"),

        round(
            sum("net_amount"),
            2
        ).alias("net_sales")
    )
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Average Order value

# COMMAND ----------

daily_sales_df = (
    daily_sales_df
    .withColumn(
        "average_order_value",
        round(
            col("net_sales") /
            when(col("completed_orders") == 0, 1)
            .otherwise(col("completed_orders")),
            2
        )
    )
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Alternative Net Sales Calculation

# COMMAND ----------

# MAGIC %md
# MAGIC net_sales = gross_sales - discount_amount - returns

# COMMAND ----------

# MAGIC %md
# MAGIC ##Calculate returned amount

# COMMAND ----------

returns_df = (
    sales_df
    .filter(col("order_status") == "RETURNED")
    .groupBy("sales_date")
    .agg(
        sum("net_amount")
        .alias("returned_amount")
    )
)

# COMMAND ----------

daily_sales_df = (
    daily_sales_df
    .join(
        returns_df,
        "sales_date",
        "left"
    )
    .fillna(0, ["returned_amount"])
    .withColumn(
        "net_sales",
        round(
            col("gross_sales")
            - col("discount_amount")
            - col("returned_amount"),
            2
        )
    )
)


# COMMAND ----------

# MAGIC %md
# MAGIC #Write to Gold Daily Sales table

# COMMAND ----------

(
    daily_sales_df
    .select(
        "sales_date",
        "total_orders",
        "completed_orders",
        "cancelled_orders",
        "returned_orders",
        col("gross_sales").cast("decimal(18,2)"),
        col("discount_amount").cast("decimal(18,2)"),
        col("net_sales").cast("decimal(18,2)"),
        col("average_order_value").cast("decimal(18,2)")
    )
    .write
    .format("delta")
    .mode("overwrite")
    .saveAsTable("gold_daily_sales")
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Validate Daily Sales load into the gold_daily_sales table

# COMMAND ----------

spark.table("medallion_architecture.gold_daily_sales").limit(4).display()

# COMMAND ----------

# MAGIC %md
# MAGIC #Business Questions

# COMMAND ----------

# MAGIC %md
# MAGIC 1. What was today's revenue

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT net_sales
# MAGIC FROM gold_daily_sales
# MAGIC WHERE sales_date = CURRENT_DATE();

# COMMAND ----------

# MAGIC %md
# MAGIC 2. What is the average order value?

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT
# MAGIC     AVG(average_order_value)
# MAGIC FROM gold_daily_sales;

# COMMAND ----------

# MAGIC %md
# MAGIC 3. Which day generated the highest revenue?

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT sales_date
# MAGIC FROM gold_daily_sales
# MAGIC ORDER BY net_sales DESC
# MAGIC LIMIT 1;
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC 4. What is the cancellation rate?

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT
# MAGIC     sales_date,
# MAGIC     ROUND(
# MAGIC         cancelled_orders * 100.0 /
# MAGIC         total_orders,
# MAGIC         2
# MAGIC     ) AS cancellation_rate_pct
# MAGIC FROM gold_daily_sales;

# COMMAND ----------

