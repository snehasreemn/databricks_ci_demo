# Databricks notebook source
# MAGIC %md
# MAGIC #Define Payments Source and Checkpoint paths

# COMMAND ----------

# MAGIC %sql
# MAGIC use catalog shopshere;
# MAGIC use schema medallion_architecture;

# COMMAND ----------

# Source location
source_path = "/Volumes/shopshere/quickstart_schema/sandbox/payments/"

# Streaming checkpoint
checkpoint_location = "/Volumes/shopshere/quickstart_schema/sandbox/payments_checkpoint/"

# COMMAND ----------

# MAGIC %md
# MAGIC #Read the Incremental Stream data for Payments

# COMMAND ----------

from pyspark.sql.types import *

payments_schema = StructType([
    StructField("payment_id", LongType(), False),         # Primary Key
    StructField("order_id", LongType(), False),           # FK -> Orders
    StructField("payment_method", StringType(), True),
    StructField("payment_amount", DecimalType(18, 2), True),
    StructField("payment_status", StringType(), True),
    StructField("payment_date", TimestampType(), True),
    StructField("updated_at", TimestampType(), True)
])

payments_df = (
    spark.readStream
         .format("cloudFiles")
         .schema(payments_schema)
         .option("cloudFiles.format", "csv")
         .option("header", "true")
         .load(source_path)
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Write the incremental stream of data into bronze_payments table

# COMMAND ----------

payments_df.writeStream.option("checkpointLocation", checkpoint_location).trigger(
    availableNow=True
).toTable("medallion_architecture.bronze_payments")

# COMMAND ----------

spark.table("medallion_architecture.bronze_payments").count()