# Databricks notebook source
# MAGIC %md
# MAGIC %md
# MAGIC #Define Inventory Source and Checkpoint paths

# COMMAND ----------

# MAGIC %sql
# MAGIC use catalog shopshere;
# MAGIC use schema medallion_architecture;

# COMMAND ----------

# Source location
source_path = "/Volumes/shopshere/quickstart_schema/sandbox/inventory/"

# Streaming checkpoint
checkpoint_location = "/Volumes/shopshere/quickstart_schema/sandbox/inventory_checkpoint/"

# COMMAND ----------

from pyspark.sql.types import *

inventory_schema = StructType([
    StructField("inventory_date", DateType(), True),
    StructField("product_id", IntegerType(), True),
    StructField("warehouse_id", StringType(), True),
    StructField("available_quantity", IntegerType(), True),
    StructField("reserved_quantity", IntegerType(), True),
    StructField("reorder_level", IntegerType(), True)
])

inventory_df = (
    spark.readStream
         .format("cloudFiles")
         .schema(inventory_schema)
         .option("cloudFiles.format", "csv")
         .option("header", "true")
         .load(source_path)
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Write the incremental stream of data into bronze_inventory table

# COMMAND ----------

inventory_df.writeStream.option("checkpointLocation", checkpoint_location).trigger(
    availableNow=True
).toTable("medallion_architecture.bronze_inventory")

# COMMAND ----------

spark.table("medallion_architecture.bronze_inventory").count()

# COMMAND ----------

