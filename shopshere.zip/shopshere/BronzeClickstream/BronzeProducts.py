# Databricks notebook source
# MAGIC %md
# MAGIC #Define Products Source and Checkpoint paths

# COMMAND ----------

# MAGIC %sql
# MAGIC use catalog shopshere;
# MAGIC use schema medallion_architecture;

# COMMAND ----------

# Source location
source_path = "/Volumes/shopshere/quickstart_schema/sandbox/products/"

# Streaming checkpoint
checkpoint_location = "/Volumes/shopshere/quickstart_schema/sandbox/products_checkpoint/"

# COMMAND ----------

# MAGIC %md
# MAGIC #Read the Incremental Stream data for Products

# COMMAND ----------

from pyspark.sql.types import *

products_schema = StructType([
    StructField("product_id", IntegerType(), True),
    StructField("product_name", StringType(), True),
    StructField("category", StringType(), True),
    StructField("subcategory", StringType(), True),
    StructField("brand", StringType(), True),
    StructField("price", DecimalType(10, 2), True),
    StructField("cost", DecimalType(10, 2), True),
    StructField("supplier_id", StringType(), True),
    StructField("product_status", StringType(), True),
    StructField("updated_at", TimestampType(), True)
])

products_df = (
    spark.readStream
         .format("cloudFiles")
         .schema(products_schema)
         .option("cloudFiles.format", "csv")
         .option("header", "true")
         .load(source_path)
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Write the incremental stream of data into bronze_products table

# COMMAND ----------

products_df.writeStream.option("checkpointLocation", checkpoint_location).trigger(
    availableNow=True
).toTable("medallion_architecture.bronze_products")

# COMMAND ----------

spark.table("medallion_architecture.bronze_products").count()

# COMMAND ----------

