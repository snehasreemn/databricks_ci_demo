# Databricks notebook source
# MAGIC %md
# MAGIC #Define OrderItems Source and Checkpoint paths

# COMMAND ----------

# MAGIC %sql
# MAGIC use catalog shopshere;
# MAGIC use schema medallion_architecture;

# COMMAND ----------

# Source location
source_path = "/Volumes/shopshere/quickstart_schema/sandbox/order_items/"

# Streaming checkpoint
checkpoint_location = "/Volumes/shopshere/quickstart_schema/sandbox/order_items_checkpoint/"

# COMMAND ----------

# MAGIC %md
# MAGIC #Read the Incremental Stream data for Order Items

# COMMAND ----------

from pyspark.sql.types import *

order_items_schema = StructType([
    StructField("order_item_id", LongType(), False),        # Primary Key
    StructField("order_id", LongType(), False),             # FK -> Orders
    StructField("product_id", IntegerType(), False),        # FK -> Products
    StructField("quantity", IntegerType(), True),
    StructField("unit_price", DecimalType(18, 2), True),
    StructField("discount", DecimalType(5, 2), True),      # percentage discount
    StructField("created_at", TimestampType(), True),
    StructField("updated_at", TimestampType(), True)
])

order_items_df = (
    spark.readStream
         .format("cloudFiles")
         .schema(order_items_schema)
         .option("cloudFiles.format", "csv")
         .option("header", "true")
         .load(source_path)
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Write the incremental stream of data into bronze_order_items table

# COMMAND ----------

order_items_df.writeStream.option("checkpointLocation", checkpoint_location).trigger(
    availableNow=True
).toTable("medallion_architecture.bronze_order_items")

# COMMAND ----------

spark.table("medallion_architecture.bronze_order_items").count()