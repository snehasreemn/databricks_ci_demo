# Databricks notebook source
# MAGIC %md
# MAGIC #Define Orders Source and Checkpoint paths

# COMMAND ----------

# MAGIC %sql
# MAGIC use catalog shopshere;
# MAGIC use schema medallion_architecture;

# COMMAND ----------

# Source location
source_path = "/Volumes/shopshere/quickstart_schema/sandbox/orders/"

# Streaming checkpoint
checkpoint_location = "/Volumes/shopshere/quickstart_schema/sandbox/orders_checkpoint/"

# COMMAND ----------

# MAGIC %md
# MAGIC #Read the Incremental Stream data for Orders

# COMMAND ----------

from pyspark.sql.types import *

orders_schema = StructType([
    StructField("order_id", LongType(), False),
    StructField("customer_id", IntegerType(), True),
    StructField("order_date", TimestampType(), True),
    StructField("order_status", StringType(), True),
    StructField("shipping_address", StringType(), True),
    StructField("total_amount", DecimalType(18, 2), True),
    StructField("created_at", TimestampType(), True),
    StructField("updated_at", TimestampType(), True)
])

orders_df = (
    spark.readStream
         .format("cloudFiles")
         .schema(orders_schema)
         .option("cloudFiles.format", "csv")
         .option("header", "true")
         .load(source_path)
)

# COMMAND ----------

# MAGIC %md
# MAGIC #Write the incremental stream of data into bronze_orders table

# COMMAND ----------

orders_df.writeStream.option("checkpointLocation", checkpoint_location).trigger(
    availableNow=True
).toTable("medallion_architecture.bronze_orders")

# COMMAND ----------

spark.table("medallion_architecture.bronze_orders").count()