# Databricks notebook source
# MAGIC %md
# MAGIC #Prerequisites - Create Catalog and Schema

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE CATALOG IF NOT EXISTS shopshere;
# MAGIC USE CATALOG shopshere;
# MAGIC CREATE SCHEMA IF NOT EXISTS medallion_architecture;
# MAGIC USE SCHEMA medallion_architecture;

# COMMAND ----------

