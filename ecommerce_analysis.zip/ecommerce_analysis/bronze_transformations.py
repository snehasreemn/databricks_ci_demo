from pyspark import pipelines as dp
from pyspark.sql.functions import *
 
orders_stagaing_directory = "/Volumes/wns07102026/quickstart_schema/sandbox/datasets/e-commerce/staging/orders/"
 
@dp.table(
    name = "bronze_orders"
)
def bronze_orders():
    df = spark.readStream.format("cloudFiles").option("cloudFiles.format","JSON").load(orders_stagaing_directory).withColumn("_ingest_timestamp", current_timestamp()).withColumn("_source_file", col("_metadata.file_path"))
    return df