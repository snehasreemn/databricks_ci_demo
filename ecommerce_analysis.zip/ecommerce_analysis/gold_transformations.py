from pyspark import pipelines as dp
from pyspark.sql.functions import *
 
orders_stagaing_directory = "/Volumes/wns07102026/quickstart_schema/sandbox/datasets/e-commerce/staging/orders/"
 
@dp.table(
    name="gold_orders"
)
def gold_orders():
    df = spark.read.table("silver_orders").groupBy("item_id").agg(sum("total_price").alias("total_revenue"))
    return df
