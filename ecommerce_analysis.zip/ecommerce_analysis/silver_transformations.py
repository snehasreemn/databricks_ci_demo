from pyspark import pipelines as dp
from pyspark.sql.functions import *
 
orders_stagaing_directory = "/Volumes/wns07102026/quickstart_schema/sandbox/datasets/e-commerce/staging/orders/"
 

@dp.table(
    name="silver_orders",
    comment = "Cleansed and Enriched Orders"
)

# @dp.expect("valid_customer_id", "customer_id IS NOT NULL")
# @dp.expect("valid_qty",col("qty") > 0)


@dp.expect("valid_customer","customer_id IS NOT NULL")
@dp.expect("valid_qty","qty > 0")
@dp.expect_or_drop("valid_transaction_date","order_ts <= current_date()+1")

def silver_orders():
    df = spark.readStream.table("bronze_orders").withColumn("total_price", col("qty")* col("price"))
    return df
 