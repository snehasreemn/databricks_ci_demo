from pyspark import pipelines as dp
from pyspark.sql.functions import *

@dp.materialized_view(
    name="cust_order_aggregation"
)
def cust_order_aggregation():
    cust_order_aggregation = spark.read.table("cust_order_denom").groupBy("customer_id").agg(sum("total_amount").alias("total_spend"), count("order_id").alias("total_orders"), avg("total_amount").alias("avg_spend"))
    return cust_order_aggregation
