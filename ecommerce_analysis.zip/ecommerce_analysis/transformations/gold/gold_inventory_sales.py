from pyspark import pipelines as dp
from pyspark.sql.functions import *
from pyspark.sql.window import Window


@dp.materialized_view(
    name="gold_inventory_sales",
    comment="Inventory and sales combined view for stock management"
)
def gold_inventory_sales():
    orders_df = (
        spark.read.table("silver_orders")
        .filter(col("order_status") == "DELIVERED")
    )

    order_items_df = spark.read.table("silver_order_items")

    # Aggregate product sales
    sales_df = (
        orders_df.alias("o")
        .join(order_items_df.alias("oi"), "order_id")
        .groupBy("product_id")
        .agg(sum("quantity").alias("sales_quantity"))
    )

    # Latest inventory snapshot
    inventory_df = spark.read.table("silver_inventory")
    w = Window.partitionBy("product_id").orderBy(col("inventory_date").desc())
    latest_inventory = (
        inventory_df
        .withColumn("rn", row_number().over(w))
        .filter("rn = 1")
        .drop("rn")
    )

    # Standardize gold inventory status (map IN_STOCK to HEALTHY_STOCK)
    inventory_gold = (
        latest_inventory
        .withColumn(
            "inventory_status",
            when(col("available_to_sell") <= 0, "OUT_OF_STOCK")
            .when(col("available_to_sell") <= col("reorder_level"), "LOW_STOCK")
            .otherwise("HEALTHY_STOCK")
        )
    )

    # Join with products
    products_df = spark.read.table("silver_products")

    return (
        sales_df.alias("s")
        .join(inventory_gold.alias("i"), "product_id", "inner")
        .join(products_df.alias("p"), "product_id", "left")
        .select(
            "product_id",
            "product_name",
            "category",
            "sales_quantity",
            col("available_quantity").alias("available_inventory"),
            col("reserved_quantity").alias("reserved_inventory"),
            "available_to_sell",
            "inventory_status"
        )
    )