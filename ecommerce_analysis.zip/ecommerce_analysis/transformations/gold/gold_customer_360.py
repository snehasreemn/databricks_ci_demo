from pyspark import pipelines as dp
from pyspark.sql.functions import *
from pyspark.sql.window import Window


@dp.materialized_view(
    name="gold_customer_360",
    comment="360-degree customer view with order metrics, preferences, and segmentation"
)
def gold_customer_360():
    # Customer master (current customers from SCD Type 2)
    customers = (
        spark.read.table("silver_customers")
        .filter("__END_AT IS NULL")
        .select(
            "customer_id",
            concat_ws(" ", col("first_name"), col("last_name")).alias("customer_name")
        )
    )

    # Order metrics (delivered orders only)
    orders = (
        spark.read.table("silver_orders")
        .filter(col("order_status") == "DELIVERED")
    )
    order_items = spark.read.table("silver_order_items")

    # Customer sales metrics
    customer_orders = (
        orders.alias("o")
        .join(order_items.alias("oi"), "order_id")
    )

    customer_metrics = (
        customer_orders
        .groupBy("customer_id")
        .agg(
            min(to_date("order_date")).alias("first_order_date"),
            max(to_date("order_date")).alias("last_order_date"),
            countDistinct("order_id").alias("total_orders"),
            sum("quantity").alias("total_quantity"),
            round(sum("net_amount"), 2).alias("total_spend")
        )
        .withColumn(
            "average_order_value",
            round(col("total_spend") / col("total_orders"), 2)
        )
        .withColumn(
            "days_since_last_order",
            datediff(current_date(), col("last_order_date"))
        )
    )

    # Preferred category
    products = spark.read.table("silver_products")
    category_counts = (
        orders.alias("o")
        .join(order_items.alias("oi"), "order_id")
        .join(products.alias("p"), "product_id")
        .groupBy("customer_id", "p.category")
        .agg(sum("quantity").alias("qty"))
    )

    w_category = Window.partitionBy("customer_id").orderBy(col("qty").desc())
    preferred_category = (
        category_counts
        .withColumn("rn", row_number().over(w_category))
        .filter("rn = 1")
        .select("customer_id", col("category").alias("preferred_category"))
    )

    # Preferred device from clickstream
    events = spark.read.table("silver_clickstream")
    device_counts = (
        events
        .filter(col("customer_id").isNotNull())
        .groupBy("customer_id", "device_type")
        .count()
    )

    w_device = Window.partitionBy("customer_id").orderBy(col("count").desc())
    preferred_device = (
        device_counts
        .withColumn("rn", row_number().over(w_device))
        .filter("rn = 1")
        .select("customer_id", col("device_type").alias("preferred_device"))
    )

    # Customer segmentation
    customer_metrics = (
        customer_metrics
        .withColumn(
            "customer_segment",
            when(col("total_spend") >= 50000, "VIP")
            .when(col("total_spend") >= 20000, "HIGH_VALUE")
            .when(col("total_orders") >= 10, "LOYAL")
            .when(col("days_since_last_order") <= 90, "ACTIVE")
            .otherwise("INACTIVE")
        )
    )

    # Build customer 360
    return (
        customers
        .join(customer_metrics, "customer_id", "left")
        .join(preferred_category, "customer_id", "left")
        .join(preferred_device, "customer_id", "left")
        .select(
            "customer_id",
            "customer_name",
            "first_order_date",
            "last_order_date",
            "total_orders",
            "total_quantity",
            col("total_spend").cast("decimal(18,2)"),
            col("average_order_value").cast("decimal(18,2)"),
            "days_since_last_order",
            "preferred_category",
            "preferred_device",
            "customer_segment"
        )
    )