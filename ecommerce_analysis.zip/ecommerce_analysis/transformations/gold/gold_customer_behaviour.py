from pyspark import pipelines as dp
from pyspark.sql.functions import *


@dp.materialized_view(
    name="gold_customer_behavior",
    comment="Customer behavior funnel metrics from clickstream and orders"
)
def gold_customer_behavior():
    # Customer base (current customers from SCD Type 2)
    customers_df = (
        spark.read.table("silver_customers")
        .filter("__END_AT IS NULL")
        .select(
            "customer_id",
            concat_ws(" ", col("first_name"), col("last_name")).alias("customer_name")
        )
    )

    # Aggregate clickstream events
    clickstream_df = (
        spark.read.table("silver_clickstream")
        .filter(col("customer_id").isNotNull())
    )

    behavior_metrics = (
        clickstream_df
        .groupBy("customer_id")
        .agg(
            countDistinct("session_id").alias("sessions"),
            sum(when(col("event_type") == "PRODUCT_VIEW", 1).otherwise(0)).alias("product_views"),
            sum(when(col("event_type") == "ADD_TO_CART", 1).otherwise(0)).alias("add_to_cart_events"),
            sum(when(col("event_type") == "CHECKOUT", 1).otherwise(0)).alias("checkout_events"),
            sum(when(col("event_type") == "PURCHASE", 1).otherwise(0)).alias("purchases")
        )
    )

    # Calculate funnel conversion rates
    behavior_metrics = (
        behavior_metrics
        .withColumn(
            "view_to_cart_rate",
            round(when(col("product_views") > 0, col("add_to_cart_events") * 100.0 / col("product_views")).otherwise(0), 2)
        )
        .withColumn(
            "cart_to_checkout_rate",
            round(when(col("add_to_cart_events") > 0, col("checkout_events") * 100.0 / col("add_to_cart_events")).otherwise(0), 2)
        )
        .withColumn(
            "checkout_to_purchase_rate",
            round(when(col("checkout_events") > 0, col("purchases") * 100.0 / col("checkout_events")).otherwise(0), 2)
        )
        .withColumn(
            "overall_conversion_rate",
            round(when(col("sessions") > 0, col("purchases") * 100.0 / col("sessions")).otherwise(0), 2)
        )
    )

    # Build customer behavior table
    return (
        customers_df
        .join(behavior_metrics, "customer_id", "left")
        .fillna(0)
        .select(
            "customer_id",
            "customer_name",
            "sessions",
            "product_views",
            "add_to_cart_events",
            "checkout_events",
            "purchases",
            col("view_to_cart_rate").cast("decimal(10,2)"),
            col("cart_to_checkout_rate").cast("decimal(10,2)"),
            col("checkout_to_purchase_rate").cast("decimal(10,2)"),
            col("overall_conversion_rate").cast("decimal(10,2)")
        )
    )