from pyspark import pipelines as dp
from pyspark.sql.functions import *


@dp.materialized_view(
    name="gold_daily_sales",
    comment="Daily sales metrics with order status breakdown"
)
def gold_daily_sales():
    orders_df = spark.read.table("silver_orders")
    order_items_df = spark.read.table("silver_order_items")

    # Join orders and order items
    sales_df = (
        orders_df.alias("o")
        .join(order_items_df.alias("oi"), "order_id", "inner")
        .withColumn("sales_date", to_date("order_date"))
    )

    # Aggregate daily metrics
    daily_sales_df = (
        sales_df
        .groupBy("sales_date")
        .agg(
            countDistinct("order_id").alias("total_orders"),
            countDistinct(when(col("order_status") == "DELIVERED", col("order_id"))).alias("completed_orders"),
            countDistinct(when(col("order_status") == "CANCELLED", col("order_id"))).alias("cancelled_orders"),
            countDistinct(when(col("order_status") == "RETURNED", col("order_id"))).alias("returned_orders"),
            round(sum("gross_amount"), 2).alias("gross_sales"),
            round(sum("discount_amount"), 2).alias("discount_amount"),
            round(sum("net_amount"), 2).alias("net_sales")
        )
    )

    # Average order value
    daily_sales_df = (
        daily_sales_df
        .withColumn(
            "average_order_value",
            round(col("net_sales") / when(col("completed_orders") == 0, 1).otherwise(col("completed_orders")), 2)
        )
    )

    # Calculate returned amount and adjust net sales
    returns_df = (
        sales_df
        .filter(col("order_status") == "RETURNED")
        .groupBy("sales_date")
        .agg(sum("net_amount").alias("returned_amount"))
    )

    daily_sales_df = (
        daily_sales_df
        .join(returns_df, "sales_date", "left")
        .fillna(0, ["returned_amount"])
        .withColumn(
            "net_sales",
            round(col("gross_sales") - col("discount_amount") - col("returned_amount"), 2)
        )
    )

    return (
        daily_sales_df
        .select(
            "sales_date",
            "total_orders",
            "completed_orders",
            "cancelled_orders",
            "returned_orders",
            col("gross_sales").cast("decimal(18,2)"),
            col("discount_amount").cast("decimal(18,2)"),
            col("net_sales").cast("decimal(18,2)"),
            col("average_order_value").cast("decimal(18,2)")
        )
    )