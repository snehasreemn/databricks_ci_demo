from pyspark import pipelines as dp
from pyspark.sql.functions import *
from pyspark.sql.window import Window


@dp.materialized_view(
    name="gold_product_performance",
    comment="Product performance metrics with revenue and category rankings"
)
def gold_product_performance():
    orders_df = (
        spark.read.table("silver_orders")
        .filter(col("order_status") == "DELIVERED")
    )

    order_items_df = spark.read.table("silver_order_items")
    products_df = spark.read.table("silver_products")

    # Join source tables
    product_sales = (
        orders_df.alias("o")
        .join(order_items_df.alias("oi"), "order_id")
        .join(products_df.alias("p"), "product_id")
    )

    # Aggregate product metrics
    product_metrics = (
        product_sales
        .groupBy("product_id", "product_name", "category")
        .agg(
            sum("quantity").alias("units_sold"),
            countDistinct("order_id").alias("total_orders"),
            round(sum("gross_amount"), 2).alias("gross_revenue"),
            round(sum("discount_amount"), 2).alias("discount_amount"),
            round(sum("net_amount"), 2).alias("net_revenue"),
            countDistinct("customer_id").alias("unique_customers")
        )
    )

    # Calculate average selling price
    product_metrics = (
        product_metrics
        .withColumn(
            "average_selling_price",
            round(col("net_revenue") / col("units_sold"), 2)
        )
    )

    # Revenue rank across all products
    revenue_window = Window.orderBy(col("net_revenue").desc())
    product_metrics = (
        product_metrics
        .withColumn("revenue_rank", dense_rank().over(revenue_window))
    )

    # Category rank within each category
    category_window = Window.partitionBy("category").orderBy(col("net_revenue").desc())
    product_metrics = (
        product_metrics
        .withColumn("category_rank", dense_rank().over(category_window))
    )

    return (
        product_metrics
        .select(
            "product_id",
            "product_name",
            "category",
            "units_sold",
            "total_orders",
            col("gross_revenue").cast("decimal(18,2)"),
            col("discount_amount").cast("decimal(18,2)"),
            col("net_revenue").cast("decimal(18,2)"),
            col("average_selling_price").cast("decimal(18,2)"),
            "unique_customers",
            "revenue_rank",
            "category_rank"
        )
    )