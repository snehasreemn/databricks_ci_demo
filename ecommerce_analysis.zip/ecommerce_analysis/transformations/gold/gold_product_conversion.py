from pyspark import pipelines as dp
from pyspark.sql.functions import *


@dp.materialized_view(
    name="gold_product_conversion",
    comment="Product conversion funnel metrics from clickstream events"
)
def gold_product_conversion():
    clickstream_df = spark.read.table("silver_clickstream")
    products_df = spark.read.table("silver_products")

    # Aggregate product events
    product_events = (
        clickstream_df
        .filter(col("product_id").isNotNull())
        .groupBy("product_id")
        .agg(
            sum(when(col("event_type") == "PRODUCT_VIEW", 1).otherwise(0)).alias("product_views"),
            sum(when(col("event_type") == "ADD_TO_CART", 1).otherwise(0)).alias("add_to_cart_count"),
            sum(when(col("event_type") == "CHECKOUT", 1).otherwise(0)).alias("checkout_count"),
            sum(when(col("event_type") == "PURCHASE", 1).otherwise(0)).alias("purchase_count")
        )
    )

    # Calculate conversion rates
    product_conversion = (
        product_events
        .withColumn(
            "view_to_cart_rate",
            round(when(col("product_views") > 0, col("add_to_cart_count") * 100.0 / col("product_views")).otherwise(0), 2)
        )
        .withColumn(
            "cart_to_purchase_rate",
            round(when(col("add_to_cart_count") > 0, col("purchase_count") * 100.0 / col("add_to_cart_count")).otherwise(0), 2)
        )
        .withColumn(
            "overall_conversion_rate",
            round(when(col("product_views") > 0, col("purchase_count") * 100.0 / col("product_views")).otherwise(0), 2)
        )
    )

    # Add product details
    return (
        product_conversion
        .join(
            products_df.select("product_id", "product_name", "category"),
            "product_id",
            "left"
        )
        .select(
            "product_id",
            "product_name",
            "category",
            "product_views",
            "add_to_cart_count",
            "checkout_count",
            "purchase_count",
            col("view_to_cart_rate").cast("decimal(10,2)"),
            col("cart_to_purchase_rate").cast("decimal(10,2)"),
            col("overall_conversion_rate").cast("decimal(10,2)")
        )
    )