from pyspark import pipelines as dp
from pyspark.sql.functions import *


@dp.temporary_view(name="silver_customers_clean")
def silver_customers_clean():
    bronze_df = spark.readStream.table("bronze_customers")

    cleaned_df = (
        bronze_df
        .withColumn("first_name", trim(col("first_name")))
        .withColumn("last_name", trim(col("last_name")))
        .withColumn("email", lower(trim(col("email"))))
        .withColumn("phone", trim(col("phone")))
        .withColumn("city", initcap(trim(col("city"))))
        .withColumn("state", upper(trim(col("state"))))
        .withColumn("country", upper(trim(col("country"))))
        .withColumn("customer_status", upper(trim(col("customer_status"))))
        .withColumn(
            "email",
            when(
                col("email").rlike(
                    r'^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$'
                ),
                col("email")
            )
        )
        .withColumn(
            "phone",
            when(length(trim(col("phone"))) == 0, None)
            .otherwise(col("phone"))
        )
        .withColumn(
            "email",
            when(length(trim(col("email"))) == 0, None)
            .otherwise(col("email"))
        )
        .withColumn(
            "customer_status",
            when(
                col("customer_status").isin("ACTIVE", "INACTIVE"),
                col("customer_status")
            )
            .otherwise("INACTIVE")
        )
    )

    return (
        cleaned_df
        .withColumn(
            "hash_value",
            sha2(
                concat_ws(
                    "|",
                    coalesce(col("first_name"), lit("")),
                    coalesce(col("last_name"), lit("")),
                    coalesce(col("email"), lit("")),
                    coalesce(col("phone"), lit("")),
                    coalesce(col("city"), lit("")),
                    coalesce(col("state"), lit("")),
                    coalesce(col("country"), lit("")),
                    coalesce(col("customer_status"), lit(""))
                ),
                256
            )
        )
    )


dp.create_streaming_table(
    name="silver_customers",
    comment="Cleansed and Enriched Customers"
)

dp.create_auto_cdc_flow(
    target="silver_customers",
    source="silver_customers_clean",
    keys=["customer_id"],
    sequence_by="updated_at",
    except_column_list=["_ingest_timestamp", "_source_file", "_rescued_data"],
    stored_as_scd_type=2
)