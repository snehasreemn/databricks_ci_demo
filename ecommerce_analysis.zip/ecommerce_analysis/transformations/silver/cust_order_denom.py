from pyspark import pipelines as dp
from pyspark.sql.functions import *

@dp.table(
    name = "cust_order_denom"
)


def cust_order_denom():
    cust_order_denom_df = (
    spark.readStream.table("bronze_customers").alias("c").join(
    spark.readStream.table("bronze_orders").alias("o"), col("c.customer_id") == col("o.customer_id"))
    .drop(
        col("o._rescued_data"),
        col("o._ingest_timestamp"),
        col("o.customer_id"),
        col("o._source_file"),
        col("o.created_at"),
        col("o.updated_at"),
    )
    )
    return cust_order_denom_df
