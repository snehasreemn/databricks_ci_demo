from pyspark import pipelines as dp
from pyspark.sql.functions import *


# Temporary view: clean and validate payments from bronze
@dp.temporary_view(name="silver_payments_clean")
def silver_payments_clean():
    bronze_payments = spark.readStream.table("bronze_payments")

    # Valid orders for FK validation (batch read from streaming table)
    valid_orders = (
        spark.read.table("silver_orders")
        .select("order_id")
        .distinct()
    )

    # Validate order FK (stream-static join)
    payments_valid = (
        bronze_payments.join(valid_orders, "order_id", "inner")
    )

    # Standardize payment_method (normalize common variants)
    payments_cleaned = (
        payments_valid
        .withColumn(
            "payment_method",
            upper(trim(col("payment_method")))
        )
        .withColumn(
            "payment_method",
            when(
                col("payment_method").isin("UPI", "GOOGLEPAY", "PHONEPE", "GPAY"),
                "UPI"
            )
            .when(
                col("payment_method").isin("CREDIT CARD", "DEBIT CARD", "CARD"),
                "CARD"
            )
            .when(
                col("payment_method").isin("CASH ON DELIVERY", "COD"),
                "COD"
            )
            .otherwise(col("payment_method"))
        )
    )

    # Standardize payment_status (default to PENDING if invalid)
    payments_cleaned = (
        payments_cleaned
        .withColumn(
            "payment_status",
            upper(trim(col("payment_status")))
        )
        .withColumn(
            "payment_status",
            when(
                col("payment_status").isin("SUCCESS", "FAILED", "PENDING", "REFUNDED"),
                col("payment_status")
            ).otherwise("PENDING")
        )
    )

    return payments_cleaned


# Temporary view: valid payments (amount >= 0) with business flags
@dp.temporary_view(name="silver_payments_valid")
def silver_payments_valid():
    return (
        spark.readStream.table("silver_payments_clean")
        .filter(col("payment_amount") >= 0)
        .withColumn(
            "is_successful",
            when(col("payment_status") == "SUCCESS", lit(True)).otherwise(lit(False))
        )
        .withColumn(
            "is_failed",
            when(col("payment_status") == "FAILED", lit(True)).otherwise(lit(False))
        )
        .withColumn(
            "is_refunded",
            when(col("payment_status") == "REFUNDED", lit(True)).otherwise(lit(False))
        )
    )


# Streaming table: silver_payments target for Auto CDC
dp.create_streaming_table(
    name="silver_payments",
    comment="Cleansed and validated payments with business flags"
)

# Auto CDC: upsert valid payments by payment_id, keeping latest by updated_at (SCD Type 1)
dp.create_auto_cdc_flow(
    target="silver_payments",
    source="silver_payments_valid",
    keys=["payment_id"],
    sequence_by="updated_at",
    except_column_list=["_ingest_timestamp", "_source_file", "_rescued_data"],
    stored_as_scd_type=1
)


# Streaming table: quarantine for invalid records (negative payment amount)
@dp.table(name="quarantine_payments")
def quarantine_payments():
    return (
        spark.readStream.table("silver_payments_clean")
        .filter(col("payment_amount") < 0)
    )
