from pyspark import pipelines as dp
from pyspark.sql.functions import *


# Temporary view: clean and standardize products from bronze
@dp.temporary_view(name="silver_products_clean")
def silver_products_clean():
    bronze_products = spark.readStream.table("bronze_products")

    # Standardize text fields
    products_cleaned = (
        bronze_products
        .withColumn(
            "product_name",
            initcap(trim(col("product_name")))
        )
        .withColumn(
            "category",
            initcap(trim(col("category")))
        )
        .withColumn(
            "subcategory",
            initcap(trim(col("subcategory")))
        )
        .withColumn(
            "brand",
            initcap(trim(col("brand")))
        )
        .withColumn(
            "supplier_id",
            upper(trim(col("supplier_id")))
        )
        .withColumn(
            "product_status",
            upper(trim(col("product_status")))
        )
    )

    # Validate product_status and default to ACTIVE if invalid
    products_cleaned = (
        products_cleaned
        .withColumn(
            "product_status",
            when(
                col("product_status").isin("ACTIVE", "DISCONTINUED"),
                col("product_status")
            ).otherwise("ACTIVE")
        )
    )

    return products_cleaned


# Temporary view: valid products (price >= 0, cost >= 0, category not null/empty, product_name not null)
@dp.temporary_view(name="silver_products_valid")
def silver_products_valid():
    return (
        spark.readStream.table("silver_products_clean")
        .filter(
            (col("price") >= 0) &
            (col("cost") >= 0) &
            col("category").isNotNull() &
            (trim(col("category")) != "") &
            col("product_name").isNotNull()
        )
    )


# Streaming table: silver_products target for Auto CDC
dp.create_streaming_table(
    name="silver_products",
    comment="Cleansed and validated products"
)

# Auto CDC: upsert valid products by product_id, keeping latest by updated_at (SCD Type 1)
dp.create_auto_cdc_flow(
    target="silver_products",
    source="silver_products_valid",
    keys=["product_id"],
    sequence_by="updated_at",
    except_column_list=["_ingest_timestamp", "_source_file", "_rescued_data"],
    stored_as_scd_type=1
)


# Streaming table: quarantine for invalid records (bad price/cost, missing category/name)
@dp.table(name="quarantine_products")
def quarantine_products():
    return (
        spark.readStream.table("silver_products_clean")
        .filter(
            (col("price") < 0) |
            (col("cost") < 0) |
            col("category").isNull() |
            (trim(col("category")) == "") |
            col("product_name").isNull()
        )
    )