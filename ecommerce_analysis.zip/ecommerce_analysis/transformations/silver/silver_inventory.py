from pyspark import pipelines as dp
from pyspark.sql.functions import *


# Temporary view: clean and validate inventory from bronze
@dp.temporary_view(name="silver_inventory_clean")
def silver_inventory_clean():
    bronze_inventory = spark.readStream.table("bronze_inventory")

    # Valid products for FK validation (batch read from streaming table)
    valid_products = (
        spark.read.table("silver_products")
        .select("product_id")
        .distinct()
    )

    # Validate product FK (stream-static join)
    inventory_valid = (
        bronze_inventory.join(valid_products, "product_id", "inner")
    )

    return inventory_valid


# Temporary view: valid inventory with calculations and status classification
@dp.temporary_view(name="silver_inventory_valid")
def silver_inventory_valid():
    return (
        spark.readStream.table("silver_inventory_clean")
        .filter(
            (col("available_quantity") >= 0) &
            (col("reserved_quantity") >= 0) &
            (col("reorder_level") >= 0) &
            (col("reserved_quantity") <= col("available_quantity"))
        )
        .withColumn(
            "available_to_sell",
            col("available_quantity") - col("reserved_quantity")
        )
        .withColumn(
            "inventory_status",
            when(col("available_to_sell") <= 0, "OUT_OF_STOCK")
            .when(col("available_to_sell") <= col("reorder_level"), "LOW_STOCK")
            .otherwise("IN_STOCK")
        )
    )


# Streaming table: silver_inventory target for Auto CDC
dp.create_streaming_table(
    name="silver_inventory",
    comment="Cleansed and validated inventory with status classification"
)

# Auto CDC: upsert valid inventory by composite key, keeping latest by _ingest_timestamp (SCD Type 1)
dp.create_auto_cdc_flow(
    target="silver_inventory",
    source="silver_inventory_valid",
    keys=["inventory_date", "product_id", "warehouse_id"],
    sequence_by="_ingest_timestamp",
    except_column_list=["_ingest_timestamp", "_source_file", "_rescued_data"],
    stored_as_scd_type=1
)


# Streaming table: quarantine for invalid records (bad quantities or reserved > available)
@dp.table(name="quarantine_inventory")
def quarantine_inventory():
    return (
        spark.readStream.table("silver_inventory_clean")
        .filter(
            (col("available_quantity") < 0) |
            (col("reserved_quantity") < 0) |
            (col("reorder_level") < 0) |
            (col("reserved_quantity") > col("available_quantity"))
        )
    )

