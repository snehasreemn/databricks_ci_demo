from pyspark import pipelines as dp
from pyspark.sql.functions import *


# Temporary view: clean, validate, and enrich clickstream events from bronze
@dp.temporary_view(name="silver_clickstream_valid")
def silver_clickstream_valid():
    bronze_clickstream = spark.readStream.table("bronze_clickstream")

    # Valid customers for FK validation (batch read from SCD Type 2 table)
    valid_customers = (
        spark.read.table("silver_customers")
        .filter("__END_AT IS NULL")
        .select(col("customer_id").cast("int").alias("customer_id"))
    )

    # Valid products for FK validation (batch read from streaming table)
    valid_products = (
        spark.read.table("silver_products")
        .select("product_id")
    )

    # Validate event_time (not null, not in the future)
    valid_events = (
        bronze_clickstream
        .filter(col("event_time").isNotNull())
        .filter(col("event_time") <= current_timestamp())
    )

    # Standardize event_type (normalize common variants)
    clickstream_cleaned = (
        valid_events
        .withColumn("event_type", upper(trim(col("event_type"))))
        .withColumn(
            "event_type",
            when(col("event_type").isin("PRODUCT VIEW", "PRODUCTVIEW", "VIEW_PRODUCT"), "PRODUCT_VIEW")
            .when(col("event_type").isin("ADD TO CART", "ADDTOCART"), "ADD_TO_CART")
            .when(col("event_type").isin("REMOVE FROM CART", "REMOVEFROMCART"), "REMOVE_FROM_CART")
            .when(col("event_type").isin("BUY", "ORDER", "PURCHASED"), "PURCHASE")
            .otherwise(col("event_type"))
        )
    )

    # Validate customer_id (nullable — left join, keep if null or matches valid customer)
    valid_customer_events = (
        clickstream_cleaned.alias("c")
        .join(
            valid_customers.alias("cust"),
            col("c.customer_id") == col("cust.customer_id"),
            "left"
        )
        .filter(
            col("c.customer_id").isNull() | col("cust.customer_id").isNotNull()
        )
        .select("c.*")
    )

    # Validate product_id (nullable — left join, keep if null or matches valid product)
    valid_product_events = (
        valid_customer_events.alias("c")
        .join(
            valid_products.alias("p"),
            col("c.product_id") == col("p.product_id"),
            "left"
        )
        .filter(
            col("c.product_id").isNull() | col("p.product_id").isNotNull()
        )
        .select("c.*")
    )

    # Derive event_date, event_hour, and is_anonymous
    return (
        valid_product_events
        .withColumn("event_date", to_date(col("event_time")))
        .withColumn("event_hour", hour(col("event_time")))
        .withColumn("is_anonymous", when(col("customer_id").isNull(), lit(True)).otherwise(lit(False)))
    )


# Streaming table: silver_clickstream target for Auto CDC
dp.create_streaming_table(
    name="silver_clickstream",
    comment="Cleansed and validated clickstream events with enrichment"
)

# Auto CDC: upsert valid events by event_id, keeping latest by event_time (SCD Type 1)
dp.create_auto_cdc_flow(
    target="silver_clickstream",
    source="silver_clickstream_valid",
    keys=["event_id"],
    sequence_by="event_time",
    except_column_list=["_ingest_timestamp", "_source_file", "_rescued_data"],
    stored_as_scd_type=1
)


# Streaming table: quarantine for invalid events (null or future event_time)
@dp.table(name="quarantine_clickstream")
def quarantine_clickstream():
    return (
        spark.readStream.table("bronze_clickstream")
        .filter(
            col("event_time").isNull() | (col("event_time") > current_timestamp())
        )
    )
