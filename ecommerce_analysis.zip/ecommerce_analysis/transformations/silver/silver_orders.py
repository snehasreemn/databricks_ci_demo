from pyspark import pipelines as dp
from pyspark.sql.functions import *


# Temporary view: clean and validate orders from bronze
@dp.temporary_view(name="silver_orders_clean")
def silver_orders_clean():
    bronze_orders = spark.readStream.table("bronze_orders")

    # Current customers for validation (batch read from SCD Type 2 table)
    customers = (
        spark.read.table("silver_customers")
        .filter("__END_AT IS NULL")
        .select("customer_id")
        .distinct()
    )

    # Standardize order_status and default to PLACED if invalid
    orders_cleaned = (
        bronze_orders
        .withColumn(
            "order_status",
            upper(trim(col("order_status")))
        )
        .withColumn(
            "order_status",
            when(
                col("order_status").isin(
                    "PLACED", "CONFIRMED", "SHIPPED", "DELIVERED", "CANCELLED", "RETURNED"
                ),
                col("order_status")
            ).otherwise("PLACED")
        )
    )

    # Validate customers exist (stream-static join)
    orders_valid_customers = (
        orders_cleaned.join(customers, "customer_id", "inner")
    )

    # Validate dates: order_date must not be in the future
    orders_valid_dates = (
        orders_valid_customers
        .filter(col("order_date") <= current_timestamp())
    )

    return orders_valid_dates


# Temporary view: good orders (amount >= 0) with business flags
@dp.temporary_view(name="silver_orders_good")
def silver_orders_good():
    return (
        spark.readStream.table("silver_orders_clean")
        .filter(col("total_amount") >= 0)
        .withColumn(
            "is_cancelled",
            when(col("order_status") == "CANCELLED", lit(True)).otherwise(lit(False))
        )
        .withColumn(
            "is_returned",
            when(col("order_status") == "RETURNED", lit(True)).otherwise(lit(False))
        )
        .withColumn(
            "is_completed",
            when(col("order_status") == "DELIVERED", lit(True)).otherwise(lit(False))
        )
    )


# Streaming table: silver_orders target for Auto CDC
dp.create_streaming_table(
    name="silver_orders",
    comment="Cleansed and validated orders with business flags"
)

# Auto CDC: upsert good orders by order_id, keeping latest by updated_at (SCD Type 1)
dp.create_auto_cdc_flow(
    target="silver_orders",
    source="silver_orders_good",
    keys=["order_id"],
    sequence_by="updated_at",
    except_column_list=["_ingest_timestamp", "_source_file", "_rescued_data"],
    stored_as_scd_type=1
)


# Streaming table: quarantine for bad records (negative amounts)
@dp.table(name="quarantine_orders")
def quarantine_orders():
    return (
        spark.readStream.table("silver_orders_clean")
        .filter(col("total_amount") < 0)
    )

