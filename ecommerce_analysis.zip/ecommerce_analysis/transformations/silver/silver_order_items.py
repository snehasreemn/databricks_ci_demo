from pyspark import pipelines as dp
from pyspark.sql.functions import *


# Temporary view: clean and validate order items from bronze
@dp.temporary_view(name="silver_order_items_clean")
def silver_order_items_clean():
    bronze_order_items = spark.readStream.table("bronze_order_items")

    # Valid orders for FK validation (batch read from streaming table)
    valid_orders = (
        spark.read.table("silver_orders")
        .select("order_id")
        .distinct()
    )

    # Valid products for FK validation (batch read from bronze, since silver_products doesn't exist)
    valid_products = (
        spark.read.table("bronze_products")
        .select("product_id")
        .distinct()
    )

    # Validate order FK (stream-static join)
    order_valid_df = (
        bronze_order_items.join(valid_orders, "order_id", "inner")
    )

    # Validate product FK (stream-static join)
    validated_df = (
        order_valid_df.join(valid_products, "product_id", "inner")
    )

    return validated_df


# Temporary view: valid order items with business calculations
@dp.temporary_view(name="silver_order_items_valid")
def silver_order_items_valid():
    return (
        spark.readStream.table("silver_order_items_clean")
        .filter(
            (col("quantity") > 0) &
            (col("unit_price") >= 0) &
            (col("discount") >= 0) &
            (col("discount") <= 1)
        )
        .withColumn(
            "gross_amount",
            round(col("quantity") * col("unit_price"), 2)
        )
        .withColumn(
            "discount_amount",
            round(col("gross_amount") * col("discount"), 2)
        )
        .withColumn(
            "net_amount",
            round(col("gross_amount") - col("discount_amount"), 2)
        )
    )


# Streaming table: silver_order_items target for Auto CDC
dp.create_streaming_table(
    name="silver_order_items",
    comment="Cleansed and validated order items with business calculations"
)

# Auto CDC: upsert valid order items by order_item_id, keeping latest by updated_at (SCD Type 1)
dp.create_auto_cdc_flow(
    target="silver_order_items",
    source="silver_order_items_valid",
    keys=["order_item_id"],
    sequence_by="updated_at",
    except_column_list=["_ingest_timestamp", "_source_file", "_rescued_data"],
    stored_as_scd_type=1
)


# Streaming table: quarantine for invalid records (bad quantity/price/discount)
@dp.table(name="quarantine_order_items")
def quarantine_order_items():
    return (
        spark.readStream.table("silver_order_items_clean")
        .filter(
            (col("quantity") <= 0) |
            (col("unit_price") < 0) |
            (col("discount") < 0) |
            (col("discount") > 1)
        )
    )