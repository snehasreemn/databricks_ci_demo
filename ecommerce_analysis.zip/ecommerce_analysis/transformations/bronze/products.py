from pyspark import pipelines as dp
from pyspark.sql.functions import *

source_path = "/Volumes/shopshere/quickstart_schema/sandbox/products/"

@dp.table(
    name = "bronze_products"
)


def bronze_products():
    products_df = (
        spark.readStream
        .format("cloudFiles")
        .option("cloudFiles.format", "CSV")
        .option("header", "true")
        .option("cloudFiles.inferColumnTypes", "true")
        .load(source_path)
        .withColumns({
            "_ingest_timestamp": current_timestamp(),
            "_source_file": col("_metadata.file_path")
        })
    )
    return products_df
