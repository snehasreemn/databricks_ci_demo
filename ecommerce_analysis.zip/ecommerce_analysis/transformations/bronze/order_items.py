from pyspark import pipelines as dp
from pyspark.sql.functions import *

source_path = "/Volumes/shopshere/quickstart_schema/sandbox/order_items/"

@dp.table(
    name = "bronze_order_items"
)


def bronze_order_items():
    order_items_df = (
        spark.readStream
        .format("cloudFiles")
        .option("cloudFiles.format", "CSV")
        .option("header", "true")
        .option("cloudFiles.inferColumnTypes", "true")
        .load(source_path)
        .withColumns({
            "_ingest_timestamp": current_timestamp(),
            "_source_file": col("_metadata.file_path")
        })
    )
    return order_items_df
