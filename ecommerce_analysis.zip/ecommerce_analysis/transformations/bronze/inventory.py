from pyspark import pipelines as dp
from pyspark.sql.functions import *

source_path = "/Volumes/shopshere/quickstart_schema/sandbox/inventory/"

@dp.table(
    name = "bronze_inventory"
)

def bronze_inventory():
    inventory_df = (
        spark.readStream
        .format("cloudFiles")
        .option("cloudFiles.format", "CSV")
        .option("header", "true")
        .option("cloudFiles.inferColumnTypes", "true")
        .load(source_path)
        .withColumns({
            "_ingest_timestamp": current_timestamp(),
            "_source_file": col("_metadata.file_path")
        })
    )
    return inventory_df
